#if defined(_WIN32)
#include <Windows.h>
#elif defined(linux) || defined(unix)
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#endif

#include <stdio.h>



typedef enum {
	DEBUG_PRINT = 0,
	ERROR_PRINT,
	NO_PRINT,
}log_level_t;




#define TEST_CAMERA
//#define TEST_IMAGE

#if defined(TEST_CAMERA)
#define IMAGE_AND_TEMP_OUTPUT

<<<<<<< HEAD
//#define IMAGE_OUTPUT
//#define TEMP_OUTPUT
#endif
=======
#define TEST_CAMERA
//#define TEST_IMAGE
>>>>>>> b82bb0077d8ef9b413c02b20042a66945c517178
