#include <iostream>
#include <fstream>
#include "libirdistort.h"
#include "libircmd.h"
#include "libiruvc.h"
#include "pthread.h"
#include "camera.h"
#include "display.h"
#include "sample.h"
#if defined(_WIN32)
#include <Windows.h>
#elif defined(linux) || defined(unix)
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#endif
#define OPENCV_ENABLE
#ifdef OPENCV_ENABLE
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp> 
#include <opencv2/highgui/highgui_c.h> 
//using namespace cv;
#endif

using namespace std;

template <typename T>
void load(const char* name, T* data, size_t len) {
    ifstream in(name, ios::binary);
    in.read((char*)data, sizeof(T) * len);
    in.close();
}

template <typename T>
void save(const char* name, const T* data, size_t len) {
    ofstream out(name, ios::binary);
    out.write((const char*)data, sizeof(T) * len);
    out.close();
}


void load_stream_frame_info(StreamFrameInfo_t* stream_frame_info)
{
#if defined(IMAGE_AND_TEMP_OUTPUT)
    {
        stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height / 2;
        stream_frame_info->image_info.rotate_side = NO_ROTATE;
        stream_frame_info->image_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        stream_frame_info->image_info.pseudo_color_status = PSEUDO_COLOR_OFF;
        stream_frame_info->image_info.img_enhance_status = IMG_ENHANCE_OFF;
        stream_frame_info->image_info.input_format = INPUT_FMT_YUV422; //only Y14 or Y16 mode can use enhance and pseudo color
        stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

        stream_frame_info->temp_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->temp_info.height = stream_frame_info->camera_param.height / 2;
        stream_frame_info->temp_info.rotate_side = NO_ROTATE;
        stream_frame_info->temp_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
        stream_frame_info->temp_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;//no temp frame input
    }
#elif defined(IMAGE_OUTPUT) || defined(TEMP_OUTPUT)
    stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
    stream_frame_info->image_info.height = stream_frame_info->camera_param.height;
    stream_frame_info->image_info.rotate_side = NO_ROTATE;
    stream_frame_info->image_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
    stream_frame_info->image_info.pseudo_color_status = PSEUDO_COLOR_OFF;
    stream_frame_info->image_info.img_enhance_status = IMG_ENHANCE_OFF;
    stream_frame_info->image_info.input_format = INPUT_FMT_YUV422; //only Y14 or Y16 mode can use enhance and pseudo color
    stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

    stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
    stream_frame_info->temp_byte_size = 0;
#else
    stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
    stream_frame_info->image_info.height = stream_frame_info->camera_param.height;
    stream_frame_info->image_info.rotate_side = NO_ROTATE;
    stream_frame_info->image_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
    stream_frame_info->image_info.pseudo_color_status = PSEUDO_COLOR_OFF;
    stream_frame_info->image_info.img_enhance_status = IMG_ENHANCE_OFF;
    stream_frame_info->image_info.input_format = INPUT_FMT_YUV422; //only Y14 or Y16 mode can use enhance and pseudo color
    stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

    stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
    stream_frame_info->temp_byte_size = 0;
#endif
    create_data_demo(stream_frame_info);
}



void yuyv_to_y10(uint8_t* yuyv_data, int pix_num, uint16_t* y10_data)
{
    if (yuyv_data == NULL || y10_data == NULL)
    {
        printf("yuyv_data is null or y10_data is null\n");
        return;
    }
    for (int i = 0; i < pix_num; i++)
        y10_data[i] = yuyv_data[2 * i] <<2;
}



void y10_to_yuyv(uint16_t* y10_data,int pix_num,uint8_t* yuyv_data)
{
    if (yuyv_data == NULL || y10_data == NULL)
    {
        printf("yuyv_data is null or y10_data is null\n");
        return;
    }
    for (int i = 0; i < pix_num; i++)
    {
        yuyv_data[2 * i] = y10_data[i] >> 2;
        yuyv_data[2 * i + 1] = 128;
    }
}

int main() {

    //set priority to highest level
#if defined(_WIN32)
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
#elif defined(linux) || defined(unix)
    setpriority(PRIO_PROCESS, 0, -20);
#endif
    int same_idx = 0;
    int resolution_idx = 0;
    int rst=0;
    StreamFrameInfo_t stream_frame_info = { 0 };
    IruvcHandle_t* iruvc_handle = iruvc_create_handle();
    printf("thread_function same index:%d\n", same_idx);
#if defined(IMAGE_AND_TEMP_OUTPUT)
    resolution_idx = 1;
    rst = ir_camera_open(iruvc_handle, &stream_frame_info.camera_param, same_idx, resolution_idx);
#else
    resolution_idx = 0;
    rst = ir_camera_open(iruvc_handle, &stream_frame_info.camera_param, same_idx, resolution_idx);
#endif
    if (rst < 0)
    {
        puts("ir camera open failed!\n");
        getchar();
        return 0;
    }
    load_stream_frame_info(&stream_frame_info);
    stream_frame_info.iruvc_handle = iruvc_handle;
    stream_frame_info.ircmd_handle = ircmd_create_handle(iruvc_handle, VDCMD_I2C_USB_VDCMD);



    printf("undistort version:%s\n", ir_undistort_version());
    // ���ػ������
    double params[6];
    load("data/parameters.bin", params, 6);

    
    //stream_frame_info.raw_frame = (uint8_t*)malloc(rows * cols * 2);
    pthread_t tid_bind;
    pthread_create(&tid_bind, NULL, ir_distort_bind_infisense_device, (void*)stream_frame_info.ircmd_handle);

#if  defined(TEMP_OUTPUT)
    rst = ir_camera_stream_on(&stream_frame_info, 1);
#elif defined(IMAGE_OUTPUT) || defined(IMAGE_AND_TEMP_OUTPUT)
    rst = ir_camera_stream_on(&stream_frame_info, 0);
#endif

    if (rst < 0)
    {
        puts("ir camera stream on failed!\n");
        getchar();
        return 0;
    }

    Sleep(5000);
    //ir_undistort_set_threads(1);
    // ��ʼ��
#if defined(TEST_IMAGE)
    stream_frame_info.image_info.height = 512, stream_frame_info.image_info.width = 640;
#endif
    int rows = stream_frame_info.image_info.height, cols = stream_frame_info.image_info.width;
    ir_undistort_init(rows, cols, params, IR_BYTE2_CH1);
    // ����ͼ��
    int pix_num = rows * cols;
    // ����
#if defined(TEST_CAMERA)
    uint16_t* y10_data_image_in = (uint16_t*)malloc(rows* cols*2);
    uint16_t* y10_data_image_out = (uint16_t*)malloc(rows * cols*2);
    uint16_t* y16_data_temp_in = (uint16_t*)malloc(rows * cols * 2);
    uint16_t* y16_data_temp_out = (uint16_t*)malloc(rows * cols * 2);
    uint32_t frame_idx = 0;
    //ir_undistort_run(in, out);
#if defined(IMAGE_AND_TEMP_OUTPUT)
    while(1)
    {
        iruvc_frame_get(stream_frame_info.iruvc_handle, stream_frame_info.raw_frame);


        yuyv_to_y10(stream_frame_info.raw_frame, pix_num, y10_data_image_in);
        ir_undistort_run(y10_data_image_in, y10_data_image_out);
        y10_to_yuyv(y10_data_image_out, pix_num, stream_frame_info.image_frame);
        display_one_y10_frame(&stream_frame_info, stream_frame_info.raw_frame, rows, cols, "raw");
        display_one_y10_frame(&stream_frame_info, stream_frame_info.image_frame, rows, cols, "undistort");

        uint16_t* y16_data_temp_in = (uint16_t*)(stream_frame_info.raw_frame + pix_num * 2);
        ir_undistort_run(y16_data_temp_in, y16_data_temp_out);
      

        uint16_t raw_data_before_undistort = y16_data_temp_in[10000];
        uint16_t raw_data_after_undistort = y16_data_temp_out[10000];
        if (frame_idx % 100 == 0)
        {
            printf("before undistort:%f after undistort:%f\n", \
                (double)raw_data_before_undistort / 64 - 273, (double)raw_data_after_undistort / 64 - 273);
        }
        frame_idx++;
    }
#elif defined(IMAGE_OUTPUT)
    while (1)
    {
        iruvc_frame_get(stream_frame_info.iruvc_handle, stream_frame_info.raw_frame);


        yuyv_to_y10(stream_frame_info.raw_frame, pix_num, y10_data_image_in);
        ir_undistort_run(y10_data_image_in, y10_data_image_out);
        y10_to_yuyv(y10_data_image_out, pix_num, stream_frame_info.image_frame);
        display_one_y10_frame(&stream_frame_info, stream_frame_info.raw_frame, rows, cols, "raw");
        display_one_y10_frame(&stream_frame_info, stream_frame_info.image_frame, rows, cols, "undistort");
        frame_idx++;
    }
#elif defined(TEMP_OUTPUT)
    while (1)
    {
        iruvc_frame_get(stream_frame_info.iruvc_handle, stream_frame_info.raw_frame);
        uint16_t* y16_data_temp_in = (uint16_t*)(stream_frame_info.raw_frame);
        ir_undistort_run(y16_data_temp_in, y16_data_temp_out);
        uint16_t raw_data_before_undistort = y16_data_temp_in[10000];
        uint16_t raw_data_after_undistort = y16_data_temp_out[10000];
        if (frame_idx % 100 == 0)
        {
            printf("before undistort:%f after undistort:%f\n", \
                (double)raw_data_before_undistort / 64 - 273, (double)raw_data_after_undistort / 64 - 273);
        }
        frame_idx++;
    }
#endif
    free(y10_data_image_in);
    free(y10_data_image_out);
    free(y16_data_temp_in);
    free(y16_data_temp_out);
#elif defined(TEST_IMAGE)
    uint16_t* in = new uint16_t[rows * cols];
    uint16_t* out = new uint16_t[rows * cols];
    load("data/data_y10.bin", in, rows * cols);
    ir_undistort_run(in, out);
    y10_to_yuyv(in, pix_num, stream_frame_info.raw_frame);
    y10_to_yuyv(out, pix_num, stream_frame_info.image_frame);
    display_one_y10_frame(&stream_frame_info, stream_frame_info.raw_frame, rows, cols, "raw");
    display_one_y10_frame(&stream_frame_info, stream_frame_info.image_frame, rows, cols, "undistort");
    getchar();
    save("result.bin", out, rows * cols);
    delete[] in;
    delete[] out;
#endif

    
    // ����

    ir_undistort_destroy();
    return 0;
}



