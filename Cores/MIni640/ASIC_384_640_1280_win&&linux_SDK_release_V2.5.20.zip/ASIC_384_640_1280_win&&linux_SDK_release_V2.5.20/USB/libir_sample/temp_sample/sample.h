#define HAVE_STRUCT_TIMESPEC

#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include <pthread.h>
#include "libiruvc.h"
#include "libirtemp.h"
#include "libirparse.h"
#include "libircmd.h"
#include "sample_version.h"

#define OPENCV_ENABLE
#ifdef OPENCV_ENABLE
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp> 
#include <opencv2/highgui/highgui_c.h> 
//using namespace cv;
#endif

#if defined(_WIN32)
#include <Windows.h>
#elif defined(linux) || defined(unix)
#include <unistd.h>
#include <sys/time.h>
#include "libiri2c.h"
#include <sys/resource.h>
#endif


#define COREECT_TABLE_VERSION_LEN	256
#define COREECT_TABLE_LEN			4*14*64
#define PID_TYPE1	0x5830 
#define PID_TYPE2	0x5840 
#define VID_TYPE	0x0BDA 

//#define IMAGE_AND_TEMP_OUTPUT	//normal mode:get 1 image frame and temp frame at the same time 
//#define IMAGE_OUTPUT	//only image frame
#define TEMP_OUTPUT		//only temp frame

#define STREAM_TIME 10000  //unit:s
extern uint8_t is_streaming;


typedef struct {
    EnvParam_t org_env_param;
    EnvParam_t new_env_param;
    uint8_t gain_flag;
    EnvFactor_t org_env_factor;
    EnvFactor_t new_env_factor;
    uint16_t nuc_table[8192];
}TempCalInfo_t;


typedef struct {
    float ems;  // ems: Ŀ�귢����(0.01-1)
    float ta;   // ta:�����¶�(��λ:���϶�)
    float tu;   // tu:�����¶�(��λ:���϶�)
    float dist; // dist:Ŀ�����(0.25-49.99,��λ:m)
    float hum;  // hum: �������ʪ��(0-1)
}NewCorrectParam_t;

typedef struct {
    uint16_t width;
    uint16_t height;
    uint32_t byte_size;
}FrameInfo_t;

typedef struct {
    IruvcHandle_t* iruvc_handle;
    IrcmdHandle_t* ircmd_handle;
    UserCallback_t callback;
    uint8_t* raw_frame;
    uint8_t* image_frame;
    uint32_t image_byte_size;
    uint8_t* temp_frame;
    uint32_t temp_byte_size;
    FrameInfo_t image_info;
    FrameInfo_t temp_info;
    CameraParam_t camera_param;
    timeval timer;
    uint8_t* image_tmp_frame1;
    uint8_t* image_tmp_frame2;
    uint8_t is_streaming;
}StreamFrameInfo_t;

typedef enum {
	DEBUG_PRINT = 0,
	ERROR_PRINT,
	NO_PRINT,
}log_level_t;
