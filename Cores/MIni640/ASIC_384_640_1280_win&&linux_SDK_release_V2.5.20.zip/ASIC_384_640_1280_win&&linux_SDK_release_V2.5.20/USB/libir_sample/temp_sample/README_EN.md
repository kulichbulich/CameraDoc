# libirsample program structure and user's manual



## 1.  Program compilation method

On windows, a complete VS project is provided in the libir_sample folder, the opencv library and pthreadVC2.dll are required to run the example (already placed).

On linux, there are `Makefile` and `CMakeLists.txt` files in libir_sample, you need to remove the opencv2 folder at compile time (Linux needs to install it separately). If you don't need opencv, you can comment `#define OPENCV_ENABLE` in the sample.h file, and comment opencv related content in the `Makefile` or `CMakeLists.txt` before compiling.



## 2. User's manual

### 2.1 Camera connection

In the main function of sample.cpp, the corresponding camera is selected by calling ir_camera_oepn, and get the relevant parameters information(stream_frame_info) from the camera.

After obtaining the parameter information, it is required to call load_stream_frame_info function to supplement  the settings for display and temperature function, such as: width and height information,  apply for buffer space, and so on.

```c
		stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
		stream_frame_info->image_info.height = stream_frame_info->camera_param.height / 2;

		stream_frame_info->temp_info.width = stream_frame_info->camera_param.width;
		stream_frame_info->temp_info.height = stream_frame_info->camera_param.height / 2;
		stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
		stream_frame_info->temp_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2; //no temp frame input


        stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height;
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
        stream_frame_info->temp_byte_size = 0;
```

The following is the definition of the StreamFrameInfo_t structure. Note these parameters:

FrameInfo_t-width/height: width and height parameters, need to be filled in.

StreamFrameInfo_t-image_byte_size/temp_byte_size: the byte size of the input frame. If it is filled in 0, then no data can be received. Fill it in according to the size of the data that needs to be split.

```c
typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t byte_size;
}FrameInfo_t;

typedef struct {
    IruvcHandle_t* iruvc_handle;
    IrcmdHandle_t* ircmd_handle;
    UserCallback_t callback;
    uint8_t* raw_frame;
    uint8_t* image_frame;
    uint32_t image_byte_size;
    uint8_t* temp_frame;
    uint32_t temp_byte_size;
    FrameInfo_t image_info;
    FrameInfo_t temp_info;
    CameraParam_t camera_param;
    time_t timer;
}StreamFrameInfo_t;
```



### 2.2 Streaming control

After opening the device and getting the relevant parameter information, and after initializing the display related parameters, you can call ir_camera_stream_on  function to stream. Then use `stream_operation` to display and measure the temperature of the raw frames.

```c
 while (stream_frame_info->is_streaming && (i <= STREAM_TIME * stream_frame_info->camera_param.fps))//display stream_time seconds
        {
            r = iruvc_frame_get(stream_frame_info->iruvc_handle, stream_frame_info->raw_frame);
            if (r < 0)
            {
                overtime_cnt++;
            }
            else
            {
                overtime_cnt = 0;
            }
            if (r < 0 && overtime_cnt >= overtime_threshold)
            {
                ir_camera_stream_off(stream_frame_info);
                printf("uvc_frame_get failed\n ");
                return NULL;
            }
            if (stream_frame_info->raw_frame != NULL)
            {
                raw_data_cut((uint8_t*)stream_frame_info->raw_frame, stream_frame_info->image_byte_size, \
                    stream_frame_info->temp_byte_size, (uint8_t*)stream_frame_info->image_frame, \
                    (uint8_t*)stream_frame_info->temp_frame);
#if defined(IMAGE_AND_TEMP_OUTPUT)                
                display_one_frame(stream_frame_info, title);
                if (i > 100 )
                {
                 temp_res = { stream_frame_info->temp_info.width, stream_frame_info->temp_info.height };
                 point_temp_demo((uint16_t*)stream_frame_info->temp_frame, temp_res, correct_tablel, table_len);
                }
#elif defined(IMAGE_OUTPUT)
                basic_y16_preview(stream_frame_info->ircmd_handle, BASIC_Y16_MODE_YUV);
                display_one_frame(stream_frame_info, title);
#elif defined(TEMP_OUTPUT) 
                basic_y16_preview(stream_frame_info->ircmd_handle, BASIC_Y16_MODE_TEMPERATURE);
                display_one_frame(stream_frame_info, title);
                if (i > 3)
                {
                    temp_res = { stream_frame_info->image_info.width, stream_frame_info->image_info.height };
                    point_temp_demo((uint16_t*)stream_frame_info->image_frame, temp_res, correct_tablel, table_len);
                }
#endif
            }
            i++;
        }
```



### 2.3 Command send

In the `stream_operation`function, call the relevant function to get the specified point, line and frame temperature from the temperature information `temp frame`, and also call the `enhance_distance_temp_correct` function to get the temperature after correction of the specified point temperature

- If the image is composite, the temperature information `temp frame` can be used to realize the temperature measurement function.
- If it is a single image/single temperature measurement map, the image information should be called to the interface `basic_y16_preview` for the intermediate temperature map when measuring temperature, and then use this part of the data to achieve temperature measurement.



### 2.4 End program

In the `ir_camera_stream_off` function of the sample, and call `iruvc_camera_close` to disconnect the device connection.
