# libirsample示例程序结构以及使用流程介绍

## 一、程序编译方式

在windows平台，libir_sample文件夹下已经提供了一个完整的VS工程，运行示例需要opencv库和pthreadVC2.dll（已经放入）。

在linux平台，libir_sample文件夹下提供了 `Makefile` 和`CMakeLists.txt`文件，在编译时需要删除opencv2文件夹（Linux需要另行安装）。如果不需要opencv，可以在sample.h文件中，注释掉`#define OPENCV_ENABLE`，并在 `Makefile` 或`CMakeLists.txt`中注释掉opencv相关内容，然后再编译。

## 二、程序使用流程

### 1.连接机芯

在sample.cpp的main函数中，通过调用`ir_camera_open`来选择对应的机芯，并从机芯获取相关的参数信息`stream_frame_info`。

在获取到参数信息后，调用`load_stream_frame_info`函数来补充对出图和测温功能的简单设置，比如宽高信息，申请buffer空间等。

```c
		stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
		stream_frame_info->image_info.height = stream_frame_info->camera_param.height / 2;

		stream_frame_info->temp_info.width = stream_frame_info->camera_param.width;
		stream_frame_info->temp_info.height = stream_frame_info->camera_param.height / 2;
		stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
		stream_frame_info->temp_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2; //no temp frame input


        stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height;
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
        stream_frame_info->temp_byte_size = 0;
```



如下是`StreamFrameInfo_t`结构体的定义，注意这几项参数：

FrameInfo_t-width/height:宽高参数，需要填写

StreamFrameInfo_t-image_byte_size/temp_byte_size:输入帧数据的字节大小，填0即收不到数据，根据需要切分的数据大小来填写

```c
typedef struct {
    uint16_t width;
    uint16_t height;
    uint32_t byte_size;
}FrameInfo_t;

typedef struct {
    IruvcHandle_t* iruvc_handle;
    IrcmdHandle_t* ircmd_handle;
    UserCallback_t callback;
    uint8_t* raw_frame;
    uint8_t* image_frame;
    uint32_t image_byte_size;
    uint8_t* temp_frame;
    uint32_t temp_byte_size;
    FrameInfo_t image_info;
    FrameInfo_t temp_info;
    CameraParam_t camera_param;
    time_t timer;
}StreamFrameInfo_t;
```



### 2.控制出图

- 在打开设备，获取到相关的参数信息，并对display相关参数进行初始化之后，就可以调用`ir_camera_stream_on`来获取数据流。然后使用`stream_operation`对原始红外帧信息进行出图及测温操作。


- 在`stream_operation`函数中，会调用`raw_data_cut`来将红外帧信息`raw frame`切分为图像信息`image frame`和温度信息`temp frame`分别处理，调用`display_one_frame`用于出图。

```c
 while (stream_frame_info->is_streaming && (i <= STREAM_TIME * stream_frame_info->camera_param.fps))//display stream_time seconds
        {
            r = iruvc_frame_get(stream_frame_info->iruvc_handle, stream_frame_info->raw_frame);
            if (r < 0)
            {
                overtime_cnt++;
            }
            else
            {
                overtime_cnt = 0;
            }
            if (r < 0 && overtime_cnt >= overtime_threshold)
            {
                ir_camera_stream_off(stream_frame_info);
                printf("uvc_frame_get failed\n ");
                return NULL;
            }
            if (stream_frame_info->raw_frame != NULL)
            {
                raw_data_cut((uint8_t*)stream_frame_info->raw_frame, stream_frame_info->image_byte_size, \
                    stream_frame_info->temp_byte_size, (uint8_t*)stream_frame_info->image_frame, \
                    (uint8_t*)stream_frame_info->temp_frame);
#if defined(IMAGE_AND_TEMP_OUTPUT)                
                display_one_frame(stream_frame_info, title);
                if (i > 100 )
                {
                 temp_res = { stream_frame_info->temp_info.width, stream_frame_info->temp_info.height };
                 point_temp_demo((uint16_t*)stream_frame_info->temp_frame, temp_res, correct_tablel, table_len);
                }
#elif defined(IMAGE_OUTPUT)
                basic_y16_preview(stream_frame_info->ircmd_handle, BASIC_Y16_MODE_YUV);
                display_one_frame(stream_frame_info, title);
#elif defined(TEMP_OUTPUT) 
                basic_y16_preview(stream_frame_info->ircmd_handle, BASIC_Y16_MODE_TEMPERATURE);
                display_one_frame(stream_frame_info, title);
                if (i > 3)
                {
                    temp_res = { stream_frame_info->image_info.width, stream_frame_info->image_info.height };
                    point_temp_demo((uint16_t*)stream_frame_info->image_frame, temp_res, correct_tablel, table_len);
                }
#endif
            }
            i++;
        }
```



### 3.测温功能

在`stream_operation`函数中，会调用相关函数从温度信息`temp frame`中获取指定点、线、框三类温度，也可调用`enhance_distance_temp_correct`函数获取指定点温度修正后温度。

- 若为复合出图，温度信息`temp frame`可用于实现测温功能。
- 若为单成像/单测温出图，测温时需将图像信息调用接口`basic_y16_preview`进行中间温度出图，再用该部分数据实现测温。

### 4.结束程序

在sample的`ir_camera_stream_off`函数里，调用`iruvc_camera_close`来关闭设备连接。
