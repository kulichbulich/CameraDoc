#! /bin/sh

cp ../libirprocess/include/libirprocess.h  ./libs/include
cp ../libirparse/include/libirparse.h  ./libs/include
cp ../libiruvc/include/libiruvc.h  ./libs/include
cp ../libircmd/include/libircmd.h  ./libs/include
cp ../libirtemp/include/libirtemp.h  ./libs/include
cp ../libiri2c/include/libiri2c.h  ./libs/include
echo "header file copy to /include directory finished !!!"

cp ../libirprocess/build/libirprocess.so  ./libs
cp ../libirparse/build/libirparse.so  ./libs
cp ../libiruvc/build/libiruvc.so*  ./libs
cp ../libircmd/build/libircmd.so*  ./libs
cp ../libirtemp/build/libirtemp.so*  ./libs
cp ../libiri2c/build/libiri2c.so*  ./libs
echo "lib copy to ./libs directory finished !!!"
