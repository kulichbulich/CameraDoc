# libirsample示例程序结构以及使用流程介绍



## 一、程序编译方式

在windows平台，libir_sample文件夹下已经提供了一个完整的VS工程。

在linux平台，libir_sample文件夹下提供了 `CMakeLists.txt`文件。



## 二、程序使用流程

### 1.连接机芯

在sample.cpp的main函数中，通过调用`ir_camera_open`来选择对应的机芯。



### 2.更新固件

在sample.cpp的`update_fw_cmd`函数中，可以通过调用SDK的`update_fw`命令来更新固件信息。在sample.h中选择不同宏可以更新不同机芯。

```c
void update_fw_cmd(IrcmdHandle_t* handle)
{
    uint8_t* firmware_data = NULL;
    FILE* fp;
    int rst;
    printf("start to update firmware\n");
    firmware_data = (uint8_t*)malloc(256 * 1024);

#ifdef MINI_384
    fp = fopen("MN384_V1.03_20220420.bin", "rb");
#endif // MINI_384
#ifdef MINI_640
    fp = fopen("MINI640_UNIFICATION_CAL_V1.01-20220402.bin", "rb");
#endif // MINI_640
    if (fp  == NULL)
    {
        puts("Fail to open file!");
        return;
    }
    fread(firmware_data, 256 * 1024, 1, fp);
    rst = basic_update_fw(handle, firmware_data, 256 * 1024);
    fclose(fp);
    free(firmware_data);
    if (rst < 0)
    {
        printf("update firmware failed\n");
    }
    printf("update firmware success\n");
    return;
}
```



