# libirsample program structure and user's manual



## 1. Program compilation method

On windows, a complete VS project is provided in the libir_sample folder.

On linux, there are  `CMakeLists.txt` files in libir_sample.





## 2. User's manual

### 2.1 Camera connection

In the main function of sample.cpp, the corresponding camera is selected by calling ir_camera_oepn.



### 2.2 Update firmware

In the sample.cpp of the sample, call `update_fw_cmd` function to update the firmware. Select different macros in sample.h to update different movements.

```c
void update_fw_cmd(IrcmdHandle_t* handle)
{
    uint8_t* firmware_data = NULL;
    FILE* fp;
    int rst;
    printf("start to update firmware\n");
    firmware_data = (uint8_t*)malloc(256 * 1024);

#ifdef MINI_384
    fp = fopen("MN384_V1.03_20220420.bin", "rb");
#endif // MINI_384
#ifdef MINI_640
    fp = fopen("MINI640_UNIFICATION_CAL_V1.01-20220402.bin", "rb");
#endif // MINI_640
    if (fp  == NULL)
    {
        puts("Fail to open file!");
        return;
    }
    fread(firmware_data, 256 * 1024, 1, fp);
    rst = basic_update_fw(handle, firmware_data, 256 * 1024);
    fclose(fp);
    free(firmware_data);
    if (rst < 0)
    {
        printf("update firmware failed\n");
    }
    printf("update firmware success\n");
    return;
}
```

