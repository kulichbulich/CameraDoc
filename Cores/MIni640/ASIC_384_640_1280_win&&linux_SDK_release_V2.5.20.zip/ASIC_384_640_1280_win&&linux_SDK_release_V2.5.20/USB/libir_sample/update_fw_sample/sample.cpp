#include "sample.h"

#ifdef __cplusplus
extern "C" {
#endif


void log_level_register(log_level_t log_level)
{
    switch (log_level)
    {
    case(DEBUG_PRINT):
    {
        ircmd_log_register(IRCMD_LOG_DEBUG);
        iruvc_log_register(IRUVC_LOG_DEBUG);
        break;
    }
    case(ERROR_PRINT):
    {
        ircmd_log_register(IRCMD_LOG_ERROR);
        iruvc_log_register(IRUVC_LOG_ERROR);
        break;
    }
    case(NO_PRINT):
    default:
    {
        ircmd_log_register(IRCMD_LOG_NO_PRINT);
        iruvc_log_register(IRUVC_LOG_NO_PRINT);
        break;
    }
    }

}

void print_and_record_version(void)
{
    puts(SAMPLE_VERSION);
    puts(iruvc_version());
    puts(ircmd_version());
#if defined(_WIN32)
    FILE* fp = fopen(".\\libs_version.txt", "wb");
#elif defined(linux) || defined(unix)
    puts(iri2c_version());
    FILE* fp = fopen("./libs_version.txt", "wb");
    fputs(iri2c_version(), fp); fputs("\n", fp);
#endif
    fputs(SAMPLE_VERSION, fp); fputs("\n", fp);
    fputs(iruvc_version(), fp); fputs("\n", fp);
    fputs(ircmd_version(), fp); fputs("\n", fp);
    fclose(fp);
}


void update_fw_cmd(IrcmdHandle_t* handle)
{
    uint8_t* firmware_data = NULL;
    FILE* fp;
    int rst;
    printf("start to update firmware\n");
    firmware_data = (uint8_t*)malloc(256 * 1024);

#ifdef MINI_384
    fp = fopen("MN384_V1.03_20220420.bin", "rb");
#endif // MINI_384
#ifdef MINI_640
    fp = fopen("MINI640-standard-V1.0-20220429.bin", "rb");
#endif // MINI_640
    if (fp  == NULL)
    {
        puts("Fail to open file!");
        return;
    }
    fread(firmware_data, 256 * 1024, 1, fp);
    rst = basic_update_fw(handle, firmware_data, 256 * 1024);
    fclose(fp);
    free(firmware_data);
    if (rst < 0)
    {
        printf("update firmware failed\n");
    }
    printf("update firmware success\n");
    return;
}

//get specific device via pid&vid from all devices
int get_dev_index_with_pid_vid(DevCfg_t devs_cfg[])
{
    int cur_dev_index = 0;
    for (int i = 0; i < 64; i++)
    {
        if (((devs_cfg[i].vid == VID_TYPE1) && ((devs_cfg[i].pid == PID_TYPE1) || (devs_cfg[i].pid == PID_TYPE2) || (devs_cfg[i].pid == PID_TYPE3))\
            || ((devs_cfg[i].vid == VID_TYPE2) && (devs_cfg[i].pid == PID_TYPE4))))
        {
            cur_dev_index = i;
            printf("name=%s\n", devs_cfg[i].name);
            return  cur_dev_index;
        }
    }
    printf("PID or VID is wrong!\n");
    return -1;
}

int ir_camera_open(IruvcHandle_t* handle, int same_idx)
{
    DevCfg_t devs_cfg[64] = { 0 };
    CameraStreamInfo_t camera_stream_info[32] = { 0 };
    int rst = iruvc_camera_init(handle);
    if (rst < 0)
    {
        printf("uvc_camera_init:%d\n", rst);
        return rst;
    }

    memset(devs_cfg, 0, sizeof(DevCfg_t) * 64); //clear the device list before get list
    rst = iruvc_camera_list(handle, devs_cfg);
    if (rst < 0)
    {
        printf("uvc_camera_list:%d\n", rst);
        return rst;
    }

    int dev_index = 0;
    int pid, vid, resolution_idx = 0;

    dev_index = get_dev_index_with_pid_vid(devs_cfg);
    if (dev_index < 0)
    {
        printf("can not get this device!\n");
        return dev_index;
    }
    printf("cur_index=%d\n", dev_index);

    rst = iruvc_camera_info_get(handle, &(devs_cfg[dev_index]), camera_stream_info);
    if (rst < 0)
    {
        printf("uvc_camera_info_get:%d\n", rst);
        return rst;
    }

    rst = iruvc_camera_open_same(handle, devs_cfg[dev_index], same_idx);
    if (rst < 0)
    {
        printf("uvc_camera_open:%d\n", rst);
        return rst;
    }
    return 0;
}

int main(void)
{
    //set priority to highest level
#if defined(_WIN32)
    SetPriorityClass(GetCurrentProcess(), HIGH_PRIORITY_CLASS);
#elif defined(linux) || defined(unix)
    setpriority(PRIO_PROCESS, 0, -20);
#endif

    //version
    print_and_record_version();
    log_level_register(ERROR_PRINT);

    int rst, same_idx;

    //open camera 0
    same_idx = 0;
    StreamFrameInfo_t stream_frame_info1 = { 0 };
    IruvcHandle_t* iruvc_handle1 = iruvc_create_handle();
    printf("thread_function same index:%d\n", same_idx);
    rst = ir_camera_open(iruvc_handle1, same_idx);
    if (rst < 0)
    {
        puts("ir camera open failed!\n");
        getchar();
        return 0;
    }

    stream_frame_info1.iruvc_handle = iruvc_handle1;
    stream_frame_info1.ircmd_handle = ircmd_create_handle(iruvc_handle1, VDCMD_I2C_USB_VDCMD);

    log_level_register(DEBUG_PRINT);
    update_fw_cmd(stream_frame_info1.ircmd_handle);

    puts("EXIT");
    getchar();
    return 0;
}

#ifdef __cplusplus
}
#endif
