#if defined(_WIN32)
#include <Windows.h>
#elif defined(linux) || defined(unix)
#include <unistd.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "libiri2c.h"
#endif

#include <stdio.h>

#include "libiruvc.h"
#include "libircmd.h"
#include "sample_version.h"
#define PID_TYPE1	0x5830 
#define PID_TYPE2	0x5840 
#define PID_TYPE3	0x5831
#define PID_TYPE4	0x10F9
#define VID_TYPE1	0x0BDA 
#define VID_TYPE2	0x20B4 

#define MINI_384	//or MINI_384


typedef enum {
	DEBUG_PRINT = 0,
	ERROR_PRINT,
	NO_PRINT,
}log_level_t;

typedef struct {
    IruvcHandle_t* iruvc_handle;
    IrcmdHandle_t* ircmd_handle;
}StreamFrameInfo_t;

