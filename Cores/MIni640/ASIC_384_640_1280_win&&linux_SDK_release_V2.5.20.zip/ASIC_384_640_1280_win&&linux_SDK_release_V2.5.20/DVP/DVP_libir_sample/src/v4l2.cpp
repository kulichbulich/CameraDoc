#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <linux/types.h>
#include <linux/videodev2.h>
#include <string.h>

#include "v4l2.h"

#if 0
void unchar_to_Mat(unsigned char *_buffer,cv::Mat& img)
{
    for (int i = 0;i < (BUFFER_SIZE_det);i++)
    {
        img.at<cv::Vec3b>((IMAGE_HEIGHT-1-(i / (IMAGE_WIDTH*CHANNEL))),((i % (IMAGE_WIDTH*CHANNEL))/CHANNEL))[i%CHANNEL] = _buffer[i]; // BGR Mat
    }
}
#endif
void yuyv2bgr24(unsigned char*yuyv,int width,int height, unsigned char*rgb)
{   
    unsigned int i, in, rgb_index = 0;
    unsigned char y0, u0, y1, v1;
    int r, g, b;
    unsigned int x , y;

    for(in = 0; in < width * height * 2; in += 4)
    {
    y0 = yuyv[in+0];
    u0 = yuyv[in+1];
    y1 = yuyv[in+2];
    v1 = yuyv[in+3];

    for (i = 0; i < 2; i++)
    {
        if (i)
            y = y1;
        else
            y = y0;
        r = y + (140 * (v1-128))/100;  //r
        g = y - (34 * (u0-128))/100 - (71 * (v1-128))/100; //g
        b = y + (177 * (u0-128))/100; //b
        if(r > 255)   r = 255;
            if(g > 255)   g = 255;
            if(b > 255)   b = 255;
            if(r < 0)     r = 0;
            if(g < 0)     g = 0;
            if(b < 0)     b = 0;

        y = height - rgb_index/width -1;
        x = rgb_index%width;
        rgb[(y*width+x)*3+0] = b;
        rgb[(y*width+x)*3+1] = g;
        rgb[(y*width+x)*3+2] = r;
        rgb_index++;
    }
    }
}

void yuyv2bgra32(unsigned char*yuyv,int width,int height, unsigned char*bgra)
{   
    unsigned int i, in, bgra_index = 0;
    unsigned char y0, u0, y1, v1;
    int a = 0xFF, r, g, b;
    unsigned int x , y;

    for(in = 0; in < width * height * 2; in += 4)
    {
    y0 = yuyv[in+0];
    u0 = yuyv[in+1];
    y1 = yuyv[in+2];
    v1 = yuyv[in+3];

    for (i = 0; i < 2; i++)
    {
        if (i)
            y = y1;
        else
            y = y0;

        r = y + (140 * (v1-128))/100;  //r
        g = y - (34 * (u0-128))/100 - (71 * (v1-128))/100; //g
        b = y + (177 * (u0-128))/100; //b

        if(r > 255)   r = 255;
            if(g > 255)   g = 255;
            if(b > 255)   b = 255;
            if(r < 0)     r = 0;
            if(g < 0)     g = 0;
            if(b < 0)     b = 0;

        y = height - bgra_index/width -1;
        x = bgra_index%width;
        bgra[(y*width+x)*4+0] = b;
        bgra[(y*width+x)*4+1] = g;
        bgra[(y*width+x)*4+2] = r;
        bgra[(y*width+x)*4+3] = a;
        bgra_index++;
    }
    }
}

void yuyv16bgr24(unsigned char* yuv422sp, int width, int height,unsigned char*bgra)
{
    int y, cb, cr;
    int r, g, b;
    int i = 0;
    unsigned char* p_y;
    unsigned char* p_uv;
    unsigned char* p_rgb;
 
    p_y = yuv422sp;
    p_uv = p_y + width * height;    // uv������Y����
    p_rgb = bgra;
 
 
    for (i = 0; i < width * height / 2; i++)
    {
        y  = p_y[0];

        cb = p_uv[0];
        cr = p_uv[1];    // v����u����u����һ��λ��

        r = y + (140 * (cr-128))/100;  //r
        g = y - (34 * (cb-128))/100 - (71 * (cr-128))/100; //g
        b = y + (177 * (cb-128))/100; //b

        if(r > 255)   r = 255;
            if(g > 255)   g = 255;
            if(b > 255)   b = 255;
            if(r < 0)     r = 0;
            if(g < 0)     g = 0;
            if(b < 0)     b = 0;
 
        // �˴��ɵ���RGB����BMPͼƬ����ΪBGR
        // Ĭ������Ϊ��RGB
        p_rgb[0] = b;
        p_rgb[1] = g;
        p_rgb[2] = r;

 				
        y  = p_y[1];

        cb = p_uv[0];
        cr = p_uv[1];
        
 
        r = y + (140 * (cr-128))/100;  //r
        g = y - (34 * (cb-128))/100 - (71 * (cr-128))/100; //g
        b = y + (177 * (cb-128))/100; //b
 
        p_rgb[3] = b;
        p_rgb[4] = g;
        p_rgb[5] = r;
 				
        p_y += 2;
        p_uv += 2;
        p_rgb += 6;
    }
}

int img_down_scale(const unsigned char* src_img, unsigned char* dst_img, \
    int src_width, int src_height, int dst_width, int dst_height)
{
    //bilinear interpolation
    if (!src_img || !dst_img) {
        printf("input array can not be null!\n");
        return -1;
    }
    if (!dst_width || !dst_height) {
        printf("image size wrong!\n");
        return -2;
    }

    double x_ratio = (double)src_width / dst_width;
    double y_ratio = (double)src_height / dst_height;
    double aspect_ratio = 0.0f;
    int border_shift = 0;
    int h = 0, w = 0;
    int x0 = 0, x1 = 0, y0 = 0, y1 = 0;
    int dst_r = 0, dst_g = 0, dst_b = 0;

    if (x_ratio < y_ratio) {
        aspect_ratio = x_ratio;
        border_shift = (int)((src_height - (int)(dst_height * aspect_ratio)) / 2);
        for (h = 0; h < dst_height; h++) {
            for (w = 0; w < dst_width; w++) {
                double src_h = border_shift + h * aspect_ratio;
                double src_w = w * aspect_ratio;
                x0 = (int)src_w;
                x1 = x0 + 1;
                y0 = (int)src_h;
                y1 = y0 + 1;

                int rx0y0 = src_img[3 * (y0 * src_width + x0) + 0];
                int gx0y0 = src_img[3 * (y0 * src_width + x0) + 1];
                int bx0y0 = src_img[3 * (y0 * src_width + x0) + 2];

                int rx1y0 = src_img[3 * (y0 * src_width + x1) + 0];
                int gx1y0 = src_img[3 * (y0 * src_width + x1) + 1];
                int bx1y0 = src_img[3 * (y0 * src_width + x1) + 2];

                int rx0y1 = src_img[3 * (y1 * src_width + x0) + 0];
                int gx0y1 = src_img[3 * (y1 * src_width + x0) + 1];
                int bx0y1 = src_img[3 * (y1 * src_width + x0) + 2];

                int rx1y1 = src_img[3 * (y1 * src_width + x1) + 0];
                int gx1y1 = src_img[3 * (y1 * src_width + x1) + 1];
                int bx1y1 = src_img[3 * (y1 * src_width + x1) + 2];

                dst_r = (y1 - src_h) * ((x1 - src_w) * rx0y0 + (src_w - x0) * rx1y0) + (src_h - y0) * ((x1 - src_w) * rx0y1 + (src_w - x0) * rx1y1);
                dst_g = (y1 - src_h) * ((x1 - src_w) * gx0y0 + (src_w - x0) * gx1y0) + (src_h - y0) * ((x1 - src_w) * gx0y1 + (src_w - x0) * gx1y1);
                dst_b = (y1 - src_h) * ((x1 - src_w) * bx0y0 + (src_w - x0) * bx1y0) + (src_h - y0) * ((x1 - src_w) * bx0y1 + (src_w - x0) * bx1y1);

                dst_r = dst_r > 255 ? 255 : dst_r < 0 ? 0 : dst_r;
                dst_g = dst_g > 255 ? 255 : dst_g < 0 ? 0 : dst_g;
                dst_b = dst_b > 255 ? 255 : dst_b < 0 ? 0 : dst_b;

                dst_img[3 * (h * dst_width + w) + 0] = (unsigned char)dst_r;
                dst_img[3 * (h * dst_width + w) + 1] = (unsigned char)dst_g;
                dst_img[3 * (h * dst_width + w) + 2] = (unsigned char)dst_b;
            }
        }
    }
    else {
        aspect_ratio = y_ratio;
        border_shift = (int)((src_width - (int)(dst_width * aspect_ratio)) / 2);
        for (h = 0; h < dst_height; h++) {
            double src_h = h * aspect_ratio;
            for (w = 0; w < dst_width; w++) {
                double src_w = border_shift + w * aspect_ratio;
                x0 = (int)src_w;
                x1 = x0 + 1;
                y0 = (int)src_h;
                y1 = y0 + 1;

                int rx0y0 = src_img[3 * (y0 * src_width + x0) + 0];
                int gx0y0 = src_img[3 * (y0 * src_width + x0) + 1];
                int bx0y0 = src_img[3 * (y0 * src_width + x0) + 2];

                int rx1y0 = src_img[3 * (y0 * src_width + x1) + 0];
                int gx1y0 = src_img[3 * (y0 * src_width + x1) + 1];
                int bx1y0 = src_img[3 * (y0 * src_width + x1) + 2];

                int rx0y1 = src_img[3 * (y1 * src_width + x0) + 0];
                int gx0y1 = src_img[3 * (y1 * src_width + x0) + 1];
                int bx0y1 = src_img[3 * (y1 * src_width + x0) + 2];

                int rx1y1 = src_img[3 * (y1 * src_width + x1) + 0];
                int gx1y1 = src_img[3 * (y1 * src_width + x1) + 1];
                int bx1y1 = src_img[3 * (y1 * src_width + x1) + 2];

                dst_r = (y1 - src_h) * ((x1 - src_w) * rx0y0 + (src_w - x0) * rx1y0) + (src_h - y0) * ((x1 - src_w) * rx0y1 + (src_w - x0) * rx1y1);
                dst_g = (y1 - src_h) * ((x1 - src_w) * gx0y0 + (src_w - x0) * gx1y0) + (src_h - y0) * ((x1 - src_w) * gx0y1 + (src_w - x0) * gx1y1);
                dst_b = (y1 - src_h) * ((x1 - src_w) * bx0y0 + (src_w - x0) * bx1y0) + (src_h - y0) * ((x1 - src_w) * bx0y1 + (src_w - x0) * bx1y1);

                dst_r = dst_r > 255 ? 255 : dst_r < 0 ? 0 : dst_r;
                dst_g = dst_g > 255 ? 255 : dst_g < 0 ? 0 : dst_g;
                dst_b = dst_b > 255 ? 255 : dst_b < 0 ? 0 : dst_b;

                dst_img[3 * (h * dst_width + w) + 0] = (unsigned char)dst_r;
                dst_img[3 * (h * dst_width + w) + 1] = (unsigned char)dst_g;
                dst_img[3 * (h * dst_width + w) + 2] = (unsigned char)dst_b;
            }
        }
    }
    return 0;
}

BUF *v4l2(char *FILE_VIDEO,int width,int height,int format)
{
    //int i;
    //int ret = 0;
    BUF *buffers = (BUF *)malloc(sizeof (BUF));
    //open dev
    if ((buffers->fd = open(FILE_VIDEO, O_RDWR)) == -1)
    {
        printf("Error opening V4L interface\n");
        return (FALSE);
    }

    struct v4l2_capability   cap;
    memset(&cap, 0, sizeof(cap));
    //query cap
    if (ioctl(buffers->fd, VIDIOC_QUERYCAP, &cap) == -1)
    {
        printf("Error opening device %s: unable to query device.\n",FILE_VIDEO);
        return (FALSE);
    }
    else
    {
        //printf("driver:\t\t%s\n",cap.driver);
        //printf("card:\t\t%s\n",cap.card);
        //printf("bus_info:\t%s\n",cap.bus_info);
        //printf("version:\t%d\n",cap.version);
        //printf("capabilities:\t%x\n",cap.capabilities);

        if ((cap.capabilities & V4L2_CAP_VIDEO_CAPTURE) == V4L2_CAP_VIDEO_CAPTURE)
        {
            printf("Device %s: supports capture.\n",FILE_VIDEO);
        }

        if ((cap.capabilities & V4L2_CAP_STREAMING) == V4L2_CAP_STREAMING)
        {
            printf("Device %s: supports streaming.\n",FILE_VIDEO);
        }
        if (cap.capabilities & V4L2_CAP_VIDEO_CAPTURE)
            buffers->buf_type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        else if (cap.capabilities & V4L2_CAP_VIDEO_CAPTURE_MPLANE)
            buffers->buf_type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    }

    //emu all support fmt
    struct v4l2_fmtdesc fmtdesc;
    fmtdesc.index=0;
    fmtdesc.type=buffers->buf_type;
    printf("Support format:\n");
    while(ioctl(buffers->fd,VIDIOC_ENUM_FMT,&fmtdesc)!=-1)
    {
        printf("\t%d.%s\n",fmtdesc.index+1,fmtdesc.description); // get camera all support format here
        fmtdesc.index++;
    }

    struct v4l2_format fmt;
    memset(&fmt, 0, sizeof(fmt));
    //set fmt
    fmt.type = buffers->buf_type;
    fmt.fmt.pix.pixelformat = format; // output format
    fmt.fmt.pix.height = height;
    fmt.fmt.pix.width = width;
    //fmt.fmt.pix.field = V4L2_FIELD_INTERLACED;
    //fmt.fmt.pix.priv = 1;

    if(ioctl(buffers->fd, VIDIOC_S_FMT, &fmt) == -1)
    {
        printf("Unable to set format\n");
        return FALSE;
    }
    if(ioctl(buffers->fd, VIDIOC_G_FMT, &fmt) == -1)
    {
        printf("Unable to get format\n");
        return FALSE;
    }
    {
        //printf("fmt.type:\t\t%d\n",fmt.type);
        printf("pix.pixelformat:\t%c%c%c%c\n",fmt.fmt.pix.pixelformat & 0xFF, (fmt.fmt.pix.pixelformat >> 8) & 0xFF,(fmt.fmt.pix.pixelformat >> 16) & 0xFF, (fmt.fmt.pix.pixelformat >> 24) & 0xFF);
        printf("pix.height:\t\t%d\n",fmt.fmt.pix.height);
        printf("pix.width:\t\t%d\n",fmt.fmt.pix.width);
        printf("pix.field:\t\t%d\n",fmt.fmt.pix.field);
        if(fmt.fmt.pix.pixelformat==V4L2_PIX_FMT_YUYV||fmt.fmt.pix.pixelformat==V4L2_PIX_FMT_NV16){
            buffers->length = fmt.fmt.pix.width*fmt.fmt.pix.height*2;
        }else if (fmt.fmt.pix.pixelformat==V4L2_PIX_FMT_NV12){
            buffers->length = fmt.fmt.pix.width*fmt.fmt.pix.height*3/2;
        }
        buffers->width  = fmt.fmt.pix.width;
        buffers->height = fmt.fmt.pix.height;
        
    }
    //set fps
    //struct v4l2_streamparm setfps;
    //setfps.type = V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE;
    // setfps.parm.capture.timeperframe.numerator = 1;   // Per numerator seconds show denominator fps .
    // setfps.parm.capture.timeperframe.denominator = 25;
    // setfps.parm.capture.capturemode = 0;
    // if(ioctl(buffers->fd, VIDIOC_S_PARM, &setfps) == -1)
    // {
    //     printf("set fps fail !\n");
    //     return FALSE;
    // }

    // if(ioctl(buffers->fd, VIDIOC_G_PARM, &setfps) == -1)
    // {
    //     printf("get fps fail !\n");
    //     return FALSE;
    // }else
    // {
    //     printf("True video fps = %d\n",(setfps.parm.capture.timeperframe.denominator)/(setfps.parm.capture.timeperframe.numerator));
    // }

    // printf("init %s \t[OK]\n",FILE_VIDEO);
/***************************************************/
    unsigned int n_buffers;
    struct v4l2_requestbuffers req;
    memset(&req, 0, sizeof(req));
    //request for 4 buffers
    req.count = COUNT;
    req.type = buffers->buf_type;
    req.memory=V4L2_MEMORY_MMAP;
    if(ioctl(buffers->fd,VIDIOC_REQBUFS,&req)==-1)
    {
        printf("request for buffers error\n");
    }

    //mmap for buffers
    if (!buffers)
    {
        printf ("Out of memory\n");
        return(FALSE);
    }

    struct v4l2_buffer buf ;
    memset( &buf, 0, sizeof(buf) );

    for (n_buffers = 0; n_buffers < COUNT; n_buffers++)
    {
        struct v4l2_plane planes[1];
        buf.type = buffers->buf_type;
        buf.memory = V4L2_MEMORY_MMAP;
        buf.index = n_buffers;
        if (V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE == buffers->buf_type) {
            buf.m.planes = planes;
            buf.length = 1;
        }
        //query buffers
        if (ioctl (buffers->fd, VIDIOC_QUERYBUF, &buf) == -1)
        {
            printf("query buffer error\n");
            return(FALSE);
        }

        //map
        if (V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE == buffers->buf_type) {
            buffers->start[n_buffers] = mmap(NULL,buf.m.planes[0].length,PROT_READ |PROT_WRITE, MAP_SHARED, buffers->fd, buf.m.planes[0].m.mem_offset);
        }else {
            buffers->start[n_buffers] = mmap(NULL,buf.length,PROT_READ |PROT_WRITE, MAP_SHARED, buffers->fd,buf.m.offset);
        }
        if (buffers->start[n_buffers] == MAP_FAILED)
        {
            printf("buffer map error\n");
            return(FALSE);
        }
    //queue
        ioctl(buffers->fd, VIDIOC_QBUF, &buf) ;
    }
    /***************************************************/

    int type = buffers->buf_type;
    ioctl (buffers->fd, VIDIOC_STREAMON, &type) ;

    return buffers ;
}

int get_img(BUF *buffers, unsigned char *srcBuffer)
{
    // loop start
    struct v4l2_buffer dequeue ;
    dequeue.type = buffers->buf_type ;
    dequeue.memory = V4L2_MEMORY_MMAP ;

    if (V4L2_BUF_TYPE_VIDEO_CAPTURE_MPLANE == buffers->buf_type) {
        struct v4l2_plane planes[1];
        dequeue.m.planes = planes;
        dequeue.length = 1;
    }

    if(ioctl(buffers->fd, VIDIOC_DQBUF, &dequeue)==-1) // get frame
        exit(-1);
    unsigned char * buffer = (unsigned char *)buffers->start[dequeue.index];
    memcpy(srcBuffer,buffer,buffers->length);
    if(ioctl(buffers->fd, VIDIOC_QBUF, &dequeue) ==-1) exit(-1);
    return 0;
}

int close_v4l2(BUF *buffers)
{
     int type = buffers->buf_type;
     ioctl(buffers->fd, VIDIOC_STREAMOFF, &type);

     for(int i=0;i<COUNT;i++)
     {
         munmap(buffers->start[i],buffers->length);
     }
     if(buffers->fd != -1)
     {
         close(buffers->fd);
         free(buffers);
         return (TRUE);
     }
     free(buffers);
     return (FALSE);
}
