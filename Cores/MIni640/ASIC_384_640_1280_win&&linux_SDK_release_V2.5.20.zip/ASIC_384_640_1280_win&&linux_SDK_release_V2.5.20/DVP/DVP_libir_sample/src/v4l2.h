#ifndef __V4L2_H__
#define __V4L2_H__

#include <sys/mman.h>
#include <linux/types.h>
#include <string.h>

#define  TRUE   1
#define  FALSE  0
#define  COUNT  4



typedef struct buffer
{
    int fd;
    int buf_type;
    int width;
    int height;
    size_t	length;
    void * start[COUNT];
} BUF ;

extern "C"
{
    void yuyv2bgr24(unsigned char*yuyv,int width,int height, unsigned char*rgb);
    void yuyv2bgra32(unsigned char*yuyv, int width,int height,unsigned char*bgra);
    void yuyv16bgr24(unsigned char* yuv422sp, int width, int height,unsigned char*bgra);
    int img_down_scale(const unsigned char* src_img, unsigned char* dst_img,\
        int src_width, int src_height, int dst_width, int dst_height);
    BUF *v4l2(char *FILE_VIDEO,int width,int height,int format);
    int get_img(BUF *buffers, unsigned char *srcBuffer);
    int close_v4l2(BUF *buffers);

}


#endif
