#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/ioctl.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <xf86drm.h>
#include <xf86drmMode.h>
#include <drm/drm_fourcc.h>
#include "drm_display.h"

#define UNUSED(x) ((void)(x))

static int drm_dev_fd = 0;
static uint8_t buf_flag = 0;
static struct buffer_object plane_buf[2];
static struct buffer_object buf;
static drmEventContext drm_ev_cont = {};
static int fd;
static drmModeConnector *conn;
static drmModeRes *res;
static drmModePlaneRes *plane_res;
static uint32_t crtc_id;
static void write_color(struct buffer_object *bo, unsigned int color)
{
	uint8_t *pt;
	int i;

	pt = bo->vaddr;
	for (i = 0; i < (bo->size / 4); i++)
	{
		*pt = color;
		pt++;
	}
}

static int modeset_create_fb(int fd, struct buffer_object *bo)
{
	struct drm_mode_create_dumb create = {};
	struct drm_mode_map_dumb map = {};
	uint32_t handles[4] = {0}, pitches[4] = {0}, offsets[4] = {0};
	int ret;

	create.width = bo->width;
	create.height = bo->height;
	create.bpp = 24;
	drmIoctl(fd, DRM_IOCTL_MODE_CREATE_DUMB, &create);

	bo->pitch = create.pitch;
	bo->size = create.size;
	bo->handle = create.handle;

	map.handle = create.handle;
	drmIoctl(fd, DRM_IOCTL_MODE_MAP_DUMB, &map);

	bo->vaddr = mmap(0, create.size, PROT_READ | PROT_WRITE,
					 MAP_SHARED, fd, map.offset);

#if 0
	drmModeAddFB(fd, bo->width, bo->height, 24, 32, bo->pitch,
			   bo->handle, &bo->fb_id);
#else
	offsets[0] = 0;
	handles[0] = bo->handle;
	pitches[0] = bo->pitch;

	ret = drmModeAddFB2(fd, bo->width, bo->height,
						DRM_FORMAT_BGR888, handles, pitches, offsets, &bo->fb_id, 0); //DRM_FORMAT_BGR888 bmp DRM_FORMAT_XRGB8888
	if (ret)
	{
		printf("drmModeAddFB2 return err %d\n", ret);
		return 0;
	}

	printf("bo->pitch %d\n", bo->pitch);

#endif

	memset(bo->vaddr, 0xff, bo->size);

	return 0;
}

static void modeset_destroy_fb(int fd, struct buffer_object *bo)
{
	struct drm_mode_destroy_dumb destroy = {};

	drmModeRmFB(fd, bo->fb_id);

	munmap(bo->vaddr, bo->size);

	destroy.handle = bo->handle;
	drmIoctl(fd, DRM_IOCTL_MODE_DESTROY_DUMB, &destroy);
}

static void modeset_page_flip_handler(int fd, uint32_t frame,
									  uint32_t sec, uint32_t usec, void *data)
{
	uint32_t crtc_id = *(uint32_t *)data;

	drmModePageFlip(fd, crtc_id, plane_buf[buf_flag].fb_id, DRM_MODE_PAGE_FLIP_EVENT, data);

	UNUSED(frame);
	UNUSED(sec);
	UNUSED(usec);
}

void get_planes_property(int fd, drmModePlaneRes *pr)
{
	drmModeObjectPropertiesPtr props;
	int i, j;
	drmModePropertyPtr p;

	for (i = 0; i < pr->count_planes; i++)
	{

		printf("planes id %d\n", pr->planes[i]);
		props = drmModeObjectGetProperties(fd, pr->planes[i],
										   DRM_MODE_OBJECT_PLANE);

		for (j = 0; j < props->count_props; j++)
		{
			p = drmModeGetProperty(fd, props->props[j]);
			printf("get property ,name %s, id %d\n", p->name, p->prop_id);
			drmModeFreeProperty(p);
		}

		printf("\n\n");
	}
}

int drm_dev_open(int width,int height)
{

	uint32_t conn_id;
	uint32_t x, y;
	uint32_t plane_id;
	int ret;
	int rotation = 1, alpha = 10;

	fd = open("/dev/dri/card0", O_RDWR | O_CLOEXEC);

	res = drmModeGetResources(fd);
	crtc_id = res->crtcs[0];
	conn_id = res->connectors[0];

	drmSetClientCap(fd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1);
	ret = drmSetClientCap(fd, DRM_CLIENT_CAP_UNIVERSAL_PLANES, 1);
	if (ret)
	{
		printf("failed to set client cap\n");
		return -1;
	}
	plane_res = drmModeGetPlaneResources(fd);
	plane_id = plane_res->planes[0];

	printf("get plane count %d,plane_id %d\n", plane_res->count_planes, plane_id);

	conn = drmModeGetConnector(fd, conn_id);
		if ((!conn)||conn->connection != DRM_MODE_CONNECTED){
		printf("have no screen\n");
		return -1;
	}
	buf.width = conn->modes[0].hdisplay;
	buf.height = conn->modes[0].vdisplay;

	/*
	printf("get connector nanme %s,hdisplay %d, vdisplay %d,vrefresh %d\n",conn->modes[0].name,conn->modes[0].vdisplay,\
		conn->modes[0].hdisplay,conn->modes[0].vrefresh);
	modeset_create_fb(fd, &buf);
	drmModeSetCrtc(fd, crtc_id, buf.fb_id,0, 0, &conn_id, 1, &conn->modes[0]);
	write_color(&buf,0xff00ff00);
	*/

	// -------------------  overlay 1
	plane_buf[0].width = width;
	plane_buf[0].height = height;
	modeset_create_fb(fd, &plane_buf[0]);
	plane_buf[1].width = width;
	plane_buf[1].height = height;
	modeset_create_fb(fd, &plane_buf[1]);
	//write_color(&plane_buf[0], 0x00ff0000); //测试图
	//get_planes_property(fd, plane_res);  plane_res->planes[0]---系统窗口使用？plane_res->planes[1]无法缩放
	ret = drmModeSetPlane(fd, plane_res->planes[1], crtc_id, plane_buf[0].fb_id, 0,
						  0, 0, 720, 1280,
						  0, 0, (plane_buf[0].width) << 16, (plane_buf[0].height) << 16);				  
	if (ret < 0)
		printf("drmModeSetPlane err %d\n", ret);

	return 0;
}

int drm_dev_close()
{
	modeset_destroy_fb(fd, &buf);
	modeset_destroy_fb(fd, &plane_buf[1]);
	modeset_destroy_fb(fd, &plane_buf[0]);

	drmModeFreeConnector(conn);
	drmModeFreePlaneResources(plane_res);
	drmModeFreeResources(res);
	close(fd);
	return 0;
}

void drm_display(void *buff)
{
	buf_flag ^= 1;//双buff切换不会行撕裂
	memcpy(plane_buf[buf_flag].vaddr, buff, plane_buf[buf_flag].size);
	drmModeSetPlane(fd, plane_res->planes[1], crtc_id, plane_buf[buf_flag].fb_id, 0,
						  0, 0, 720, 1280,
						  0, 0, (plane_buf[buf_flag].width) << 16, (plane_buf[buf_flag].height) << 16);	
}

u_int32_t drm_get_screeninfo_width()
{
	return plane_buf[buf_flag].width;
}

u_int32_t drm_get_screeninfo_height()
{
	return plane_buf[buf_flag].height;
}
