#ifndef _SAMPLE_H_
#define _SAMPLE_H_

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include "libiri2c.h"
#include "libircmd.h"
#include <unistd.h>
#include <pthread.h>
#include "v4l2.h"
#include <linux/videodev2.h>
#include "cmd.h"
#include "drm_display.h"
#define USE_RGA

#ifdef USE_RGA
#include "rga.h"
#include "im2d_api/im2d.hpp"
#include "RgaApi.h"
#endif

#define IR_SAMPLE_VERSION "UVC_V4L2_I2C 2.0.0_beta"

#define IRWIDTH 1280
#define IRHEIGHT 1024


typedef enum {
	DEBUG_PRINT = 0,
	ERROR_PRINT,
	NO_PRINT,
}log_level_t;


#endif


