#ifndef _CMD_H_
#define _CMD_H_

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "libircmd.h"

extern bool isRUNNING;

//select the command
void command_sel(int cmd_type,IrcmdHandle_t* handle);

//command thread, get the input and select the command
void* cmd_function(void* threadarg);

#endif


