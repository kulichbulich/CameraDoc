#include "sample.h"

uint8_t *buff;
#define DISWIDTH 1280
#define DISHEIGHT 1024
struct cameraArg
{
    char *name;
    int width;
    int height;
    uint8_t *dst;
    int length;
    int fmt;
};
int kbhit(void)
{

    fd_set rfds;
    struct timeval tv;
    int retval;

    /* Watch stdin (fd 0) to see when it has input. */
    FD_ZERO(&rfds);
    FD_SET(0, &rfds);
    /* Wait up to five seconds. */
    tv.tv_sec = 0;
    tv.tv_usec = 0;

    retval = select(1, &rfds, NULL, NULL, &tv);
    /* Don't rely on the value of tv now! */

    if (retval == -1)
    {
        perror("select()");
        return 0;
    }
    else if (retval)
        return 1;
    /* FD_ISSET(0, &rfds) will be true. */
    else
        return 0;
    return 0;
}

#ifdef USE_RGA
IM_API static void empty_structure(rga_buffer_t *src, rga_buffer_t *dst, rga_buffer_t *pat, im_rect *srect, im_rect *drect, im_rect *prect) {
    if (src != NULL)
        memset(src, 0, sizeof(*src));
    if (dst != NULL)
        memset(dst, 0, sizeof(*dst));
    if (pat != NULL)
        memset(pat, 0, sizeof(*pat));
    if (srect != NULL)
        memset(srect, 0, sizeof(*srect));
    if (drect != NULL)
        memset(drect, 0, sizeof(*drect));
    if (prect != NULL)
        memset(prect, 0, sizeof(*prect));
}
#endif

void *capture_thread_func(void *vptr_args)
{
	 struct cameraArg *video = reinterpret_cast<struct cameraArg *>(vptr_args);
	    BUF *buffer = v4l2(video->name, video->width, video->height, video->fmt);
	    if (buffer == NULL)
	    {
	        perror("open devices error\n");
	        return NULL;
	    }
	        int ret = drm_dev_open(DISWIDTH,DISHEIGHT);//显示初始化
    if (ret != 0)
    {
        printf("drm dev open fail\n");
        return NULL;
    }
     unsigned char *srcBuffer_1 = (unsigned char *)malloc(sizeof(unsigned char) * buffer->length); // yuyv
     unsigned char *disBuffer = (unsigned char *)malloc(sizeof(unsigned char) * DISWIDTH*DISHEIGHT*3); // rgb
    while (isRUNNING)
    {
        if(get_img(buffer, srcBuffer_1))continue;
        //memcpy(video->dst, srcBuffer_1, video->length); //送去融合
#ifdef USE_RGA
	rga_buffer_t 	src;
    rga_buffer_t 	dst;
    rga_buffer_t pat;
    rga_info_t src_info, dst_info;
    im_rect srect;
    im_rect drect;
    im_rect prect;
    empty_structure(NULL, NULL, &pat, &srect, &drect, &prect);
    src = wrapbuffer_virtualaddr(srcBuffer_1, video->width, video->height, RK_FORMAT_YCbCr_422_SP);
    dst = wrapbuffer_virtualaddr(disBuffer,DISWIDTH,DISHEIGHT,RK_FORMAT_BGR_888);

    src_info.fd = src.fd;
    src_info.virAddr = src.vir_addr;
    src_info.mmuFlag = 1;
    rga_set_rect(&src_info.rect, srect.x, srect.y, src.width, src.height, src.wstride, src.hstride, src.format);

    dst_info.fd = dst.fd;
    dst_info.virAddr = dst.vir_addr;
    dst_info.mmuFlag = 1;
    rga_set_rect(&dst_info.rect, drect.x, drect.y, dst.width, dst.height, dst.wstride, dst.hstride, dst.format);

    src_info.rotation = HAL_TRANSFORM_ROT_90;

    //imrotate(src,dst,IM_HAL_TRANSFORM_ROT_90);//单步
    //imresize(src, dst); //单步
	//imcvtcolor(src, display, src.format, display.format); //单步
    //improcess(src, dst, pat, srect, drect, prect, IM_HAL_TRANSFORM_ROT_90); //无法旋转同时缩放，旋转后宽高保持一致
    RgaBlit(&src_info,&dst_info,NULL);//旋转+缩放+颜色转换
    drm_display(disBuffer); //送去显示
	#else
    yuyv16bgr24(srcBuffer_1, video->width, video->height, video->dst);
    //img_down_scale(video->dst, disBuffer, video->width, video->height, DISWIDTH, DISHEIGHT);
    drm_display(video->dst); //送去显示
  #endif
    }
    close_v4l2(buffer);
    drm_dev_close();
    return NULL;
}

void log_level_register(log_level_t log_level)
{
    switch(log_level)
    {
        case(DEBUG_PRINT):
        {
            ircmd_log_register(IRCMD_LOG_DEBUG);
            iri2c_log_register(IRI2C_LOG_DEBUG);
            break;
        }
        case(ERROR_PRINT):
        {
            ircmd_log_register(IRCMD_LOG_ERROR);
            iri2c_log_register(IRI2C_LOG_ERROR);
            break;
        }
        case(NO_PRINT):
        default:
        {
            ircmd_log_register(IRCMD_LOG_NO_PRINT);
            iri2c_log_register(IRI2C_LOG_NO_PRINT);
            break;
        }
    }

}


void print_and_record_version(void)
{
    puts(IR_SAMPLE_VERSION);
    puts(ircmd_version());
    puts(iri2c_version());
    FILE* fp = fopen("./libs_version.txt", "wb");
    fputs(IR_SAMPLE_VERSION, fp);fputs("\n", fp);
    fputs(ircmd_version(), fp);fputs("\n", fp);
    fputs(iri2c_version(), fp);fputs("\n", fp);
    fclose(fp);
}



int main(int argc, char *argv[])
{
    print_and_record_version();
    log_level_register(ERROR_PRINT);
    
    int fd;
    buff = (uint8_t *)malloc(1280 * 720 * 6 / 4 + IRWIDTH * IRHEIGHT * 4 + 1280 * 720 * 4);
    struct cameraArg *vlCamera, *irCamera;
    vlCamera = (struct cameraArg *)malloc(sizeof(struct cameraArg));
    irCamera = (struct cameraArg *)malloc(sizeof(struct cameraArg));
    vlCamera->name = (char*)"/dev/video0";
    vlCamera->width = 1280;
    vlCamera->height = 720;
    vlCamera->length = 1280 * 720 * 3 / 2;
    vlCamera->fmt = V4L2_PIX_FMT_YUV420;
    vlCamera->dst = buff;

    irCamera->name = (char*)"/dev/video0";
    irCamera->width = IRWIDTH;
    irCamera->height = IRHEIGHT;
    irCamera->length = IRWIDTH * IRHEIGHT * 2;
    irCamera->fmt = V4L2_PIX_FMT_NV16;
    irCamera->dst = buff + vlCamera->length;

    pthread_t capture_thread[2], cmd_thread;
    //pthread_create(&capture_thread[0], NULL, capture_thread_func, (void *)vlCamera);
    pthread_create(&capture_thread[1], NULL, capture_thread_func, (void *)irCamera);
    fd = open("/dev/video0", O_RDWR);//v4l-subdev1
    if (fd < 0)
    {
       perror("open error\n");
       return -1;
   }

   I2cHandle_t *i2c_handle = (I2cHandle_t *)malloc(sizeof(I2cHandle_t));
    i2c_handle->dev_node=(char*)malloc(20);
    memcpy(i2c_handle->dev_node,"/dev/i2c-1",20);
    i2c_device_open(i2c_handle);
    IrcmdHandle_t *ircmdHandle = ircmd_create_handle(i2c_handle, VDCMD_I2C_VDCMD);
    pthread_create(&cmd_thread, NULL, cmd_function, (void *)ircmdHandle);
   while(1){
    	sleep(1);
    	}
    free(buff);
    pthread_join(capture_thread[1], NULL);
    pthread_cancel(cmd_thread);

    return 0;
}