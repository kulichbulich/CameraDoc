/*
 * Basic stuff
 */

#include <linux/init.h>
#include <linux/module.h>
#include <linux/major.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/types.h>
#include <linux/fs.h>
#include <linux/usb.h>
#include <linux/uaccess.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include "uvccmd.h"
#define TAG "cmd"

#define MAX_DEVICE 20
static int cmd_major = 0;
static int minor = 0;
static struct class *cmd_class = NULL;
struct mutex mutex;
struct cmd_dev_data
{
	struct cdev cdev;
	struct usb_device *irusbdev; //指针
	int id;
};
struct cmd_dev_data cmd_dev[MAX_DEVICE];
int ir_camera_write_reg(struct usb_device *udev, u16 index, u8 *data, u16 length)
{
	int ret;
	ret = usb_control_msg(udev, usb_sndctrlpipe(udev, 0),
						  0x45,
						  0x41,
						  0x78,
						  index,
						  data,
						  length,
						  1000);
	if (ret < 0)
		return ret;
	else
		return 0;
}

int ir_camera_read_reg(struct usb_device *udev, u16 index, u8 *data, u16 length)
{
	int ret;

	ret = usb_control_msg(udev, usb_rcvctrlpipe(udev, 0),
						  0x44,
						  0xc1,
						  0x78,
						  index,
						  (u8 *)data,
						  length,
						  1000);
	if (ret < 0)
		return ret;
	else
		return 0;
}
static ssize_t cmd_read(struct file *file, char __user *buffer,
						size_t count, loff_t *ppos)
{
	if (*ppos)
		return 0;
	struct cmd_dev_data *dev = file->private_data;
	int ret;
	int length = 48;
	u8 id_type = 6;
	u8 data[8] = {0x05, 0x84, id_type, 0x00, 0x00, 0x00, (unsigned char)((length & 0x0000ff00) >> 8), (unsigned char)(length & 0x000000ff)};
	u8 status;
	u8 ver[48] = {0};
	ret = ir_camera_write_reg(dev->irusbdev, 0x1d00, data, 8);
	if (ret != 0)
		printk(TAG "ir_camera_write_reg ret=%d\n", ret);
	int index = 0;
	for (; index < 1000; index++)
	{
		ir_camera_read_reg(dev->irusbdev, 0x0200, &status, 1);
		if ((status & 0x01) == 0x00)
		{
			if ((status & 0x02) == 0x00)
			{
				break;
			}
			else if ((status & 0xFC) != 0x00)
			{
				return -1;
			}
		}
	}
	

	ret = ir_camera_read_reg(dev->irusbdev, 0x1d00 + 8, ver, length);
	if (ret != 0)
		printk(TAG "ir_camera_write_reg ret=%d\n", ret);

	int len = 48;
	if (copy_to_user(buffer, ver, len) != 0)
	{
		len = -EFAULT;
	}
	*ppos += len;
	return len;
}
/*
void test(void)
{
	int ret;
	int length = 48;
	u8 id_type = 6;
	u8 data[8] = {0x05, 0x84, id_type, 0x00, 0x00, 0x00, (unsigned char)((length & 0x0000ff00) >> 8), (unsigned char)(length & 0x000000ff)};
	u8 status;
	u8 ver[48] = {0};
	ret = ir_camera_write_reg(irusbdev, 0x1d00, data, 8);
	if (ret != 0)
		printk(TAG "ir_camera_write_reg ret=%d\n", ret);
	int index = 0;
	for (; index < 1000; index++)
	{
		ir_camera_read_reg(irusbdev, 0x0200, &status, 1);
		if ((status & 0x01) == 0x00)
		{
			if ((status & 0x02) == 0x00)
			{
				break;
			}
			else if ((status & 0xFC) != 0x00)
			{
				return -1;
			}
		}
	}

	ret = ir_camera_read_reg(irusbdev, 0x1d00 + 8, ver, length);
	if (ret != 0)
		printk(TAG "ir_camera_write_reg ret=%d\n", ret);
	printk(TAG " %s get code = %x %x %x %x %x %x %x %x\n", ver, ver[0], ver[1], ver[2], ver[3], ver[4], ver[5], ver[6], ver[7]);
}
*/
ssize_t cmd_write(struct file *file, const char __user *buf, size_t count, loff_t *ppos)
{
	printk(TAG " func:%s line:%d\n", __func__, __LINE__);

	return count;
}

int cmd_ioctl(struct file *file, unsigned int cmd, unsigned long arg)
{
	int ret = 0;
	unsigned char *data;
	struct ioctl_data val;
	struct cmd_dev_data *dev = file->private_data;
	if (_IOC_TYPE(cmd) != CMD_MAGIC)
		return -EINVAL;
	if (_IOC_NR(cmd) > CMD_MAX_NR)
		return -EINVAL;

	if(cmd==CMD_KBUF){
		if (copy_to_user(&dev->id, (int *)arg, 1))
		{
			ret = -EFAULT;
			goto RET;
		}
	}

	if (copy_from_user(&val, (struct ioctl_data *)arg, sizeof(struct ioctl_data)))
	{
		ret = -EFAULT;
		goto RET;
	}

	data = kmalloc(val.wLength, GFP_KERNEL);

	switch (cmd)
	{
	case CMD_GET:
		ret = usb_control_msg(dev->irusbdev, usb_rcvctrlpipe(dev->irusbdev, 0),
							  val.bRequest,
							  val.bRequestType,
							  val.wValue,
							  val.wIndex,
							  data,
							  val.wLength,
							  val.timeout);

		if (copy_to_user(val.data, data, val.wLength))
		{
			ret = -EFAULT;
			kfree(data);
			goto RET;
		}
		break;
	case CMD_SET:

		if (copy_from_user(data, val.data, val.wLength))
		{
			ret = -EFAULT;
			kfree(data);
			goto RET;
		}

		ret = usb_control_msg(dev->irusbdev, usb_sndctrlpipe(dev->irusbdev, 0),
							  val.bRequest,
							  val.bRequestType,
							  val.wValue,
							  val.wIndex,
							  data,
							  val.wLength,
							  val.timeout);

		break;
			
	}

	kfree(data);
RET:
	if (ret > 0)
		ret = 0;
	return ret;
}
static int cmd_open(struct inode *inode, struct file *file)
{
	printk(TAG " func:%s line:%d\n", __func__, __LINE__);
	struct cmd_dev_data *dev = container_of(inode->i_cdev, struct cmd_dev_data, cdev);
	file->private_data = dev;
	return 0;
}

static int cmd_release(struct inode *inode, struct file *file)
{

	printk(TAG " func:%s line:%d\n", __func__, __LINE__);

	return 0;
}

static const struct file_operations cmd_ops = {
	.owner = THIS_MODULE,
	.read = cmd_read,
	.write = cmd_write,
	.unlocked_ioctl = cmd_ioctl,
	.open = cmd_open,
	.release = cmd_release,
};

int cmd_init()
{
	//mutex_init(&mutex);
	int i;
	for(i=0;i<MAX_DEVICE;i++){
		cmd_dev[i].irusbdev = NULL;
		cmd_dev[i].id = -1;
	}
	dev_t devno = MKDEV(0, 0);
	if (cmd_major == 0)
	{
		alloc_chrdev_region(&devno, 0, MAX_DEVICE, "cmd");
		cmd_major = MAJOR(devno);
		cmd_class = class_create(THIS_MODULE, "cmd");
		if (IS_ERR(cmd_class))
		{
			printk(TAG "Error creating cmd class.\n");
			goto class_err;
		}
	}
	return 0;
class_err:
	unregister_chrdev(cmd_major, "cmd");
	return -1;
}

void cmd_exit()
{
	unregister_chrdev(cmd_major, "cmd");
	class_destroy(cmd_class);
	cmd_class = NULL;
	cmd_major = 0;
}

int cmd_add(struct usb_device *udev,int num)
{

	struct device *device;
	int ret;

	if (udev == NULL)
		return -1;
	if(cmd_dev[num].id>0){//已经占用,处理video节点多次打开问题
		cmd_dev[num].id += 1; //增加引用
		 return -1;
	}
	cmd_dev[num].irusbdev = udev;
	cmd_dev[num].id = 1;
	cdev_init(&cmd_dev[num].cdev, &cmd_ops);
	ret = cdev_add(&cmd_dev[num].cdev, MKDEV(cmd_major, num), 1);

	if (ret)
	{
		goto chrdev_err;
	}

	device = device_create(cmd_class, NULL, MKDEV(cmd_major, num), NULL, "cmd%d", num);
	if (IS_ERR(device))
	{
		printk(TAG "Error creating cmd device.\n");
		return -1;
	}

	return 0;
chrdev_err:

	return ret;
}
void cmd_del(struct usb_device *udev,int num)
{
	if (udev == NULL)
		return;
	if(cmd_dev[num].id==1){//已经占用,处理video节点多次打开问题
		device_destroy(cmd_class, MKDEV(cmd_major, num));
		cmd_dev[num].id =-1 ; //置为无效
		return ;
	}else cmd_dev[num].id -= 1;//减去引用
}
