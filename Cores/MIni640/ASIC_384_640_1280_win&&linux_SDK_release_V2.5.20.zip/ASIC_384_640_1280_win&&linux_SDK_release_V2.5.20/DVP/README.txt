当前目录文件说明：
├─libs：linux下的动静态库
│
├─DVP_libir_sample文件：示例工程文件
│
├─驱动开发参考 Driver development reference
│
├─用户开发标定
│  ├─测温与锅盖标定
│  ├─环境变量修正
│  ├─盲元标定
│  └─README.txt
│
├─原始I2C指令集 Original I2C instruction set
│
├─模组SDK接口V1.5.xlsx：依赖库的接口说明文档
├─linux DVP接口开发说明文档 Interface development instructions.docx
├─README.txt
└─DVP依赖关系Interface dependency.xlsx