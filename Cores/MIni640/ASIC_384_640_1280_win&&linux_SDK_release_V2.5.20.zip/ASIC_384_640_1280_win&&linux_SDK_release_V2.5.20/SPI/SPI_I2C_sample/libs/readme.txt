该目录为sample所需的库目录
分别为：libiruvc.so libirparse.so libirprocess.so libircmd.so libiri2c.so