#include "sample.h"



//load the stream frame info
void load_stream_frame_info(StreamFrameInfo_t* stream_frame_info)
{

    if (stream_frame_info->camera_param.height==HEIGHT*2)
    {
        stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height/2;
        stream_frame_info->image_info.rotate_side = NO_ROTATE;
        stream_frame_info->image_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        stream_frame_info->image_info.pseudo_color_status = PSEUDO_COLOR_OFF;
        stream_frame_info->image_info.input_format = INPUT_FMT_YUV422;
        stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

        stream_frame_info->temp_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->temp_info.height = stream_frame_info->camera_param.height/2;
        stream_frame_info->temp_info.rotate_side = NO_ROTATE;
        stream_frame_info->temp_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width*stream_frame_info->image_info.height*2;
        stream_frame_info->temp_byte_size = stream_frame_info->temp_info.width*stream_frame_info->temp_info.height*2;  //has temp frame input
    }
    else if(stream_frame_info->camera_param.height==HEIGHT)
    {
		stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height;
        stream_frame_info->image_info.rotate_side = NO_ROTATE;
        stream_frame_info->image_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        stream_frame_info->image_info.pseudo_color_status = PSEUDO_COLOR_OFF;
        stream_frame_info->image_info.input_format = INPUT_FMT_YUV422;
        stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

        stream_frame_info->temp_info.width = 0;
        stream_frame_info->temp_info.height = 0;
        stream_frame_info->temp_info.rotate_side = NO_ROTATE;
        stream_frame_info->temp_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
         
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width*stream_frame_info->image_info.height*2;
        stream_frame_info->temp_byte_size = stream_frame_info->temp_info.width*stream_frame_info->temp_info.height*2;  //no temp frame input
	}

    create_data_demo(stream_frame_info);
}
void log_level_register(log_level_t log_level)
{
    switch(log_level)
    {
        case(DEBUG_PRINT):
        {
            iruvc_log_register(IRUVC_LOG_DEBUG);
            iri2c_log_register(IRI2C_LOG_DEBUG);
            ircmd_log_register(IRCMD_LOG_DEBUG);
            irproc_log_register(IRPROC_LOG_DEBUG);
            irparse_log_register(IRPARSE_LOG_DEBUG);
            break;
        }
        case(ERROR_PRINT):
        {
            iruvc_log_register(IRUVC_LOG_ERROR);
            iri2c_log_register(IRI2C_LOG_ERROR);
            ircmd_log_register(IRCMD_LOG_ERROR);
            irproc_log_register(IRPROC_LOG_ERROR);
            irparse_log_register(IRPARSE_LOG_ERROR);
            break;
        }
        case(NO_PRINT):
        default:
        {
            iruvc_log_register(IRUVC_LOG_NO_PRINT);
            iri2c_log_register(IRI2C_LOG_NO_PRINT);
            ircmd_log_register(IRCMD_LOG_NO_PRINT);
            irproc_log_register(IRPROC_LOG_NO_PRINT);
            irparse_log_register(IRPARSE_LOG_NO_PRINT);
            break;
        }
    }

}

void print_and_record_version(void)
{
    puts(IR_SAMPLE_VERSION);
    puts(irproc_version());
    puts(irparse_version());
    puts(iruvc_version());
    puts(ircmd_version());
    puts(iri2c_version());
    FILE* fp = fopen("../libs_version.txt", "wb");
    fputs(IR_SAMPLE_VERSION, fp);fputs("\n", fp);
    fputs(irproc_version(), fp);fputs("\n", fp);
    fputs(irparse_version(), fp);fputs("\n", fp);
    fputs(iruvc_version(), fp);fputs("\n", fp);
    fputs(ircmd_version(), fp);fputs("\n", fp);
    fputs(iri2c_version(), fp);fputs("\n", fp);
    fclose(fp);
}

int main(void)
{
    //version
    print_and_record_version();
    log_level_register(ERROR_PRINT);
#if defined(LOOP_TEST)
    for (int i = 0;i < 100;i++)
    {
#endif
        int rst;
        StreamFrameInfo_t stream_frame_info = { 0 };
        stream_frame_info.camera_param.width=WIDTH;
        stream_frame_info.i2c_handle=(I2cHandle_t*)malloc(sizeof(I2cHandle_t));
        stream_frame_info.i2c_handle->dev_node=(char*)malloc(20);
        memcpy(stream_frame_info.i2c_handle->dev_node,"/dev/i2c-1",20);
        i2c_device_open(stream_frame_info.i2c_handle);
        stream_frame_info.ircmd_handle = ircmd_create_handle(stream_frame_info.i2c_handle, VDCMD_I2C_VDCMD);

#if defined(NORMAL_MODE) 
        stream_frame_info.camera_param.height=HEIGHT*2;   //384(640): image   576(1024):image+temperature
        stream_frame_info.frame_putput_format = IMAGE_AND_TEMP_MEANWHILE;
		rst = basic_preview_mode_select(stream_frame_info.ircmd_handle, BASIC_VOSPI_MODE, BASIC_FRAME_COMPOSITE_DATA);
#elif defined(INTERLACE_MODE)
        stream_frame_info.camera_param.height=HEIGHT*2;   //384(640): image   576(1024):image+temperature
        stream_frame_info.frame_putput_format = IMAGE_AND_TEMP_INTERLACE;
		rst = basic_preview_mode_select(stream_frame_info.ircmd_handle, BASIC_VOSPI_MODE, BASIC_FRAME_COMPOSITE_DATA);
#elif defined(IMAGE_OUTPUT_MODE) 
        stream_frame_info.camera_param.height=HEIGHT;   //384(640): image   288(512):image/temperature
        stream_frame_info.frame_putput_format = ONLY_IMAGE;
		rst = basic_preview_mode_select(stream_frame_info.ircmd_handle, BASIC_VOSPI_MODE, BASIC_SINGLE_IMAGE_OR_TEMP);
#elif defined(TEMP_OUTPUT_MODE)
        stream_frame_info.camera_param.height=HEIGHT;   //384(640): image   288(512):image/temperature
        stream_frame_info.frame_putput_format = ONLY_TEMP;
		rst = basic_preview_mode_select(stream_frame_info.ircmd_handle, BASIC_VOSPI_MODE, BASIC_SINGLE_IMAGE_OR_TEMP);
#endif
    load_stream_frame_info(&stream_frame_info);
    init_pthread_sem();
        sleep(5);
        if (rst < 0)
        {
            puts("ir camera stream on failed!\n");
            getchar();
            return 0;
        }

        //display_init();
        
        spi_and_sem_init();
        is_streaming = 1;

    printf("pthread_create\n");
        pthread_create(&tid_display, NULL, display_function, &stream_frame_info);
        pthread_create(&tid_stream, NULL, stream_function, &stream_frame_info);
        pthread_create(&tid_cmd, NULL, cmd_function,  &stream_frame_info);
		pthread_join(tid_display, NULL);
        pthread_cancel(tid_stream);
        pthread_cancel(tid_cmd);

        destroy_pthread_sem();
        //i2c_stop_stream(0);
#if defined(LOOP_TEST)
        printf("test cycle=%d\n",i);
    }
#endif
    puts("EXIT");
    getchar();
    return 0;
}
