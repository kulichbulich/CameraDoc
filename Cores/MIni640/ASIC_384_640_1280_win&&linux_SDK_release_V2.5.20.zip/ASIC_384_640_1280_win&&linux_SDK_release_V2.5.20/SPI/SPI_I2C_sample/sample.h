#include <unistd.h>
#include <stdio.h>
#include "libiri2c.h"
#include "cmd.h"
#include "camera.h"
#include "display.h"
#include "data.h"

#define IR_SAMPLE_VERSION "libirsample 2.0.2"

//#define LOOP_TEST

typedef enum {
	DEBUG_PRINT = 0,
	ERROR_PRINT,
	NO_PRINT,
}log_level_t;


//#define LOOP_TEST

#define WIDTH 384
#define HEIGHT 288 

#define NORMAL_MODE	//normal mode:get 1 image frame and temp frame at the same time 
//#define INTERLACE_MODE		//get 1 temp frame per 5 image frames 
//#define IMAGE_OUTPUT_MODE	//only image frame
//#define TEMP_OUTPUT_MODE		//only temp frame
