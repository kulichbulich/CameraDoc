#ifndef _SPI_H_
#define _SPI_H_

//#ifdef __cplusplus
//extern "C" {
//#endif
int SPIDataRW	(int channel, unsigned char *tx_data, unsigned char *rx_data, int len);
int SPISetupMode (int channel, int speed, int mode);
int SPISetup	(int channel, int speed);
//#ifdef __cplusplus
//}
//#endif
#endif
