# spi_i2c_sample program structure and user's manual

this is the sample for falcon product in linux platform by SPI get stream data and I2C send command

## 1. Program structure

![](./irsample_structure.png)

As shown, the sample includes these modules: sample, camera, display, cmd etc. The function of each module as follows:

**sample module**：After configuring the relevant parameters in sample.cpp, call the camera module to establish a connection with the Infrared camera, and stream the image. Later sample module will create 3 threads: stream, display and cmd, to process the corresponding information.

**camera module**：Used to obtain the information of infrared cameras. When stream thread obtains the original infrared frames, the raw frames will be divided into the image information(image frame) and temperature information(temp frame).At the same time, the signals will be transmitted to the corresponding modules. When image frame and temp frame's processing is compete, the signals will be transmitted back to camera thread, to continue the next loop.

**display module**：After obtaining the image frame information, according to the configuration of the parameters in frame_info, the image will be processed by data format conversion, flipping, mirroring, rotation and so on.

**cmd module**：Send I2C or USB command to the infrared camera by register function.




## 2. Program use flow

### 2.1 Camera connection

In the main function of sample.cpp, the corresponding camera is selected by calling ir_camera_oepn, and get the relevant parameter information(stream_frame_info) from the camera.

After obtaining the parameter information, it is required to call load_stream_frame_info function to supplement  the settings for display module, such as: width and height information, rotation/mirror/flip settings, pseudo color included in the library enable switch, input and output frame format, apply for buffer space, and so on.

```c
        stream_frame_info->image_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->image_info.height = stream_frame_info->camera_param.height / 2;
        stream_frame_info->image_info.rotate_side = LEFT_90D;
        stream_frame_info->image_info.mirror_flip_status = STATUS_MIRROR_FLIP;
        stream_frame_info->image_info.pseudo_color_status = PSUEDO_COLOR_ON;
        stream_frame_info->image_info.input_format = INPUT_FMT_Y14;
        stream_frame_info->image_info.output_format = OUTPUT_FMT_BGR888; //if display on opencv,please select BGR888

        stream_frame_info->temp_info.width = stream_frame_info->camera_param.width;
        stream_frame_info->temp_info.height = stream_frame_info->camera_param.height / 2;
        stream_frame_info->temp_info.rotate_side = NO_ROTATE;
        stream_frame_info->temp_info.mirror_flip_status = STATUS_NO_MIRROR_FLIP;
        stream_frame_info->image_byte_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height * 2;
        stream_frame_info->temp_byte_size = stream_frame_info->temp_info.width * stream_frame_info->temp_info.height * 2;
```


The following is the definition of the StreamFrameInfo_t structure. Note these parameters:

FrameInfo_t-width/height: width and height parameters, need to be filled in.

FrameInfo_t-byte_size: byte size of current frame_info, the display_image_process function in display.cpp will be filled in automatic according to the data format while streaming. 

FrameInfo_t-rotate_side/mirror_flip_status: flip/mirror/rotate and so on status, need to be filled in.

FrameInfo_t-input_format/output_format: the data format of input and output frame, such as Y14 data input, RGB888 output, and so on, need to be filled in.

FrameInfo_t-pseudo_color_status: the switch of pseudo color. The pseudo color mapping table in the libirprocess library will be called, if the switch is turned on. Need to be filled in.

StreamFrameInfo_t-image_byte_size/temp_byte_size: the byte size of the input frame. If it is filled in 0, then no data can be received. Fill it in according to the size of the data that needs to be split.


```c
typedef struct {
    uint32_t width;
    uint32_t height;
    uint32_t byte_size;
    RotateSide_t rotate_side;
    MirrorFlipStatus_t mirror_flip_status;
    InputFormat_t  input_format;
    OutputFormat_t  output_format;
    PseudoColor_t  pseudo_color_status;
    ImgEnhance_t   img_enhance_status;
}FrameInfo_t;

typedef struct {
    I2cHandle_t* i2c_handle;
    IrcmdHandle_t* ircmd_handle;
    FrameOutputFormat_t frame_putput_format;
    uint8_t* raw_frame;
    uint8_t* image_frame;
    uint32_t image_byte_size;
    uint8_t* temp_frame;
    uint32_t temp_byte_size;
    FrameInfo_t image_info;
    FrameInfo_t temp_info;
    CameraParam_t camera_param;
}StreamFrameInfo_t;
```



### 2.2 Streaming control

After opening the device and getting the relevant parameter information, and filling in the configuration of display module, you can call ir_camera_stream_on function to stream. spi_frame_get can get the image data and temperature data of each frame. In the display_function of display.cpp, display_one_frame will be called after waiting for the signal of one frame to arrive.

```c
	while (is_streaming)
	{
		sem_wait(&image_sem);
		display_one_frame(stream_frame_info);
		sem_post(&image_done_sem);
		i++;
	}
```

In the display_one_frame fucntion, display_image_process will be called to process the image data format. According to the input and output data formats (input_format, output_format) and pseudo-color settings (pseudo_color_status ) of stream_frame_info->image_info, the libirparse will be called to do corresponding conversion. And do flip, mirror, rotation operations according to the mirror_flip_status and rotate_side of stream_frame_info->image_info. Finally, it is displayed by the imshow function of opencv.

```c
	display_image_process(stream_frame_info->image_frame, pix_num, &stream_frame_info->image_info);
	if ((stream_frame_info->image_info.rotate_side == LEFT_90D)|| \
		(stream_frame_info->image_info.rotate_side == RIGHT_90D))
	{
		width = stream_frame_info->image_info.height;
		height = stream_frame_info->image_info.width;
	}

	mirror_flip_demo(&stream_frame_info->image_info, image_tmp_frame2, \
					stream_frame_info->image_info.mirror_flip_status);
	rotate_demo(&stream_frame_info->image_info, image_tmp_frame2, \
				stream_frame_info->image_info.rotate_side);

	cv::Mat image = cv::Mat(height, width, CV_8UC3, image_tmp_frame2);
	putText(image, frameText, cv::Point(11, 11), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar::all(0), 1, 8);
	putText(image, frameText, cv::Point(10, 10), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar::all(255), 1, 8);
	cv::imshow("Test", image);
	cvWaitKey(5);
```

In the stream_function function, you can control the duration of the graph by setting the value of stream_time. 

```
int stream_time = 100;  //unit:s
        while (is_streaming && (i <= stream_time * fps))//display stream_time seconds
        {
            sem_wait(&image_done_sem);
            r = uvc_frame_get(stream_frame_info->raw_frame);
```





### 2.3 Command send

In the command_sel function of cmd.cpp, the corresponding commands are triggered by input different numbers.

```c
//command thread function
void* cmd_function(void* threadarg)
{
	int cmd = 1;
	while (is_streaming)
	{
		scanf("%d", &cmd);
		if (is_streaming)
		{
			command_sel(cmd);
		}
	}
	printf("cmd thread exit!!\n");
	return NULL;
}
```

Since the SPI is constantly acquiring data and stitching it into one frame, there may be a situation where the output data is changed by the command sent before the complete frame is acquired, which may cause problems with the output effect. Therefore, when sending commands that change the image effect, make sure that the previous frame is completely output before sending the command to modify the output effect.

```
sem_wait(&cmd_sem);
basic_y16_preview(handle->ircmd_handle, BASIC_Y16_MODE_YUV);
sem_post(&cmd_done_sem);
printf("y16 preview mode YUV\n");
break;
```

### 2.4 End program

In the main function of the sample, call `destroy_pthread_sem`to turn off the signal, and call `uvc_camera_close` to disconnect the device connection.

### 2.5 Compilation for different platforms

(1)First, the client platform should load the MIPI and I2C drivers.
(2)Then the customer needs to provide the cross-compilation tool chain of proposed development platform, and let us compile libiruvc, libirtemp, libirprocess, and libirparse libraries.
And put it in the LIBS directory.
(3)Compile the sample according to Makefile.


(4)Test: If the image can be output, it means that the I2C stream command is sent successfully. Then press 1 on the terminal and press Enter. If you can see that the image freezes once, it means that the shutter is successful.

