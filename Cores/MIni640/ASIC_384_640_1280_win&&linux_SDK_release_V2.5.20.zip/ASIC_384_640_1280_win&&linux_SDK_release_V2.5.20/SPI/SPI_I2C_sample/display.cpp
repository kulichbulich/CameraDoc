#include "display.h"



time_t timer0, timer1;
uint8_t is_displaying = 0;
uint8_t* image_tmp_frame1;
uint8_t* image_tmp_frame2;


//init the display parameters
void display_init(void)
{
	//is_displaying = 1;
	time_t timer0 = clock();
	time_t timer1 = timer0;
}

//recyle the display parameters
void display_release(void)
{
	//is_displaying = 0;

	if (image_tmp_frame1 != NULL)
	{
		free(image_tmp_frame1);
		image_tmp_frame1 = NULL;
	}

	if (image_tmp_frame2 != NULL)
	{
		free(image_tmp_frame2);
		image_tmp_frame2 = NULL;
	}
}

//convert the image process  image_tmp_frame2 is the default output frame
void display_image_process(uint8_t* image_frame, int pix_num, FrameInfo_t* frameinfo)
{
	if (frameinfo->input_format == INPUT_FMT_Y14)
	{
		switch (frameinfo->output_format)
		{
			case OUTPUT_FMT_Y14:
			{
				frameinfo->byte_size = pix_num * 2;
				memcpy(image_tmp_frame2, image_frame, frameinfo->byte_size);
				break;
			}
			case OUTPUT_FMT_YUV444:
			{
				frameinfo->byte_size = pix_num * 3;
				y14_to_yuv444((uint16_t *)image_frame, pix_num, image_tmp_frame1);
				memcpy(image_tmp_frame2, image_tmp_frame1, frameinfo->byte_size);
				break;
			}
			case OUTPUT_FMT_YUV422:
			{
				frameinfo->byte_size = pix_num * 2;
				if (frameinfo->pseudo_color_status == PSEUDO_COLOR_ON)
				{
					y14_map_to_yuyv_pseudocolor((uint16_t*)image_frame, pix_num, IRPROC_COLOR_MODE_3,image_tmp_frame1);
					yuv422_to_rgb(image_tmp_frame1, pix_num,image_tmp_frame2);
				}
				else
				{
					y14_to_yuv444((uint16_t*)image_frame, pix_num, image_tmp_frame1);
					yuv444_to_yuv422(image_tmp_frame1, pix_num, image_tmp_frame2);
				}
				break;
			}
			case OUTPUT_FMT_RGB888:
			{
				frameinfo->byte_size = pix_num * 3;
				if (frameinfo->pseudo_color_status == PSEUDO_COLOR_ON)
				{
					y14_map_to_yuyv_pseudocolor((uint16_t*)image_frame, pix_num, IRPROC_COLOR_MODE_3,image_tmp_frame1 );
					yuv422_to_rgb(image_tmp_frame1, pix_num,image_tmp_frame1);
				}
				else
				{
					y14_to_rgb((uint16_t*)image_frame, pix_num, image_tmp_frame1);
					memcpy(image_tmp_frame2, image_tmp_frame1, frameinfo->byte_size);
				}
				break;
			}
			case OUTPUT_FMT_BGR888:
			default:
			{
				frameinfo->byte_size = pix_num * 3;
				if (frameinfo->pseudo_color_status == PSEUDO_COLOR_ON)
				{
					//y14_pseudocolor_mapping_rgb((uint16_t*)image_frame, pix_num, psdcolor_rgb_mapping_table,image_tmp_frame1);
					y14_map_to_yuyv_pseudocolor((uint16_t*)image_frame, pix_num, IRPROC_COLOR_MODE_3,image_tmp_frame1 );
					yuv422_to_rgb(image_tmp_frame1, pix_num,image_tmp_frame1);
					rgb_to_bgr(image_tmp_frame1, pix_num, image_tmp_frame2);
				}
				else
				{
					y14_to_rgb((uint16_t*)image_frame, pix_num, image_tmp_frame1);
					rgb_to_bgr(image_tmp_frame1, pix_num, image_tmp_frame2);
				}
				break;
			}
		}
	}
	else if (frameinfo->input_format == INPUT_FMT_YUV422)
	{
		switch (frameinfo->output_format)
		{
			case OUTPUT_FMT_Y14:
			{
				frameinfo->byte_size = 0;
				printf("convert error!\n");
				break;
			}
			case OUTPUT_FMT_YUV444:
			{
				frameinfo->byte_size = 0;
				printf("convert error!\n");
				break;
			}
			case OUTPUT_FMT_YUV422:
			{
				frameinfo->byte_size = pix_num * 2;
				memcpy(image_tmp_frame2, image_frame, pix_num * 2);
				break;
			}
			case OUTPUT_FMT_RGB888:
			{
				frameinfo->byte_size = pix_num * 3;
				yuv422_to_rgb((uint8_t*)image_frame, pix_num, image_tmp_frame2);
				break;
			}
			case OUTPUT_FMT_BGR888:
			default:
			{
				frameinfo->byte_size = pix_num * 3;
				yuv422_to_rgb((uint8_t*)image_frame, pix_num, image_tmp_frame1);
				rgb_to_bgr(image_tmp_frame1, pix_num, image_tmp_frame2);
				break;
			}
		}
	}
}

irproc_src_fmt_t format_converter(OutputFormat_t output_format)
{
	switch (output_format)
	{
	case OUTPUT_FMT_Y14:
		return IRPROC_SRC_FMT_Y14;
		break;
	case OUTPUT_FMT_YUV422:
		return IRPROC_SRC_FMT_YUV422;
		break;
	case OUTPUT_FMT_YUV444:
		return IRPROC_SRC_FMT_YUV444;
		break;
	case OUTPUT_FMT_RGB888:
		return IRPROC_SRC_FMT_RGB888;
		break;
	case OUTPUT_FMT_BGR888:
		return IRPROC_SRC_FMT_BGR888;
		break;
	default:
		return IRPROC_SRC_FMT_Y14;
		break;
	}
}

//rotate the frame data according to rotate_side
void rotate_demo(FrameInfo_t* frame_info, uint8_t* frame, RotateSide_t rotate_side)
{
	ImageRes_t image_res = { (uint16_t)frame_info->width,(uint16_t)frame_info->height };
	irproc_src_fmt_t tmp_fmt = format_converter(frame_info->output_format);

	switch (rotate_side)
	{
	case NO_ROTATE:
		break;
	case LEFT_90D:
		rotate_left_90(frame, image_res, tmp_fmt, image_tmp_frame1);
		memcpy(frame, image_tmp_frame1, frame_info->byte_size);
		break;
	case RIGHT_90D:
		rotate_right_90(frame, image_res, tmp_fmt, image_tmp_frame1);
		memcpy(frame, image_tmp_frame1, frame_info->byte_size);
		break;
	case ROTATE_180D:
		rotate_180(frame, image_res, tmp_fmt, image_tmp_frame1);
		memcpy(frame, image_tmp_frame1, frame_info->byte_size);
		break;
	default:
		break;
	}
}

//mirror/flip the frame data according to mirror_flip_status
void mirror_flip_demo(FrameInfo_t* frame_info, uint8_t* frame, MirrorFlipStatus_t mirror_flip_status)
{
	ImageRes_t image_res = { (uint16_t)frame_info->width,(uint16_t)frame_info->height };
	irproc_src_fmt_t tmp_fmt = format_converter(frame_info->output_format);

	switch (mirror_flip_status)
	{
	case STATUS_NO_MIRROR_FLIP:
		break;
	case STATUS_ONLY_MIRROR:
		mirror(frame, image_res, tmp_fmt, image_tmp_frame1);
		memcpy(frame, image_tmp_frame1, frame_info->byte_size);
		break;
	case STATUS_ONLY_FLIP:
		flip(frame, image_res, tmp_fmt, image_tmp_frame1);
		memcpy(frame, image_tmp_frame1, frame_info->byte_size);
		break;
	case STATUS_MIRROR_FLIP:
		mirror(frame, image_res, tmp_fmt, image_tmp_frame1);
		flip(image_tmp_frame1, image_res, tmp_fmt, frame);
		break;
	default:
		break;
	}
}

//display the frame by opencv 
void display_one_frame(StreamFrameInfo_t* stream_frame_info)
{
	if (stream_frame_info == NULL)
	{
		return;
	}

	char key_press = 0;
	int rst = 0;
	/*timer0 = timer1;
	timer1 = clock();
	float frame = CLOCKS_PER_SEC / (double)(timer1 - timer0);*/
	char frameText[10] = { " " };
	//sprintf(frameText, "%.2f", frame);

	int width = stream_frame_info->image_info.width;
	int height = stream_frame_info->image_info.height;
	int pix_num = width * height;

	display_image_process(stream_frame_info->image_frame, pix_num, &stream_frame_info->image_info);
	if ((stream_frame_info->image_info.rotate_side == LEFT_90D)|| \
		(stream_frame_info->image_info.rotate_side == RIGHT_90D))
	{
		width = stream_frame_info->image_info.height;
		height = stream_frame_info->image_info.width;
	}

	mirror_flip_demo(&stream_frame_info->image_info, image_tmp_frame2, \
					stream_frame_info->image_info.mirror_flip_status);
	rotate_demo(&stream_frame_info->image_info, image_tmp_frame2, \
				stream_frame_info->image_info.rotate_side);
//printf("image_byte_size = %d\n",stream_frame_info->image_byte_size);
	cv::Mat image = cv::Mat(height, width, CV_8UC3, image_tmp_frame2);
	putText(image, frameText, cv::Point(11, 11), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar::all(0), 1, 8);
	putText(image, frameText, cv::Point(10, 10), cv::FONT_HERSHEY_PLAIN, 1, cv::Scalar::all(255), 1, 8);
	cv::imshow("Test", image);
	cvWaitKey(5);
}

//display thread function
void* display_function(void* threadarg)
{
	StreamFrameInfo_t* stream_frame_info;
	stream_frame_info = (StreamFrameInfo_t*)threadarg;
	if (stream_frame_info == NULL)
	{
		return NULL;
	}

	int pixel_size = stream_frame_info->image_info.width * stream_frame_info->image_info.height;
	//printf("pixel_size = %d\n",pixel_size);
	if (image_tmp_frame1 == NULL)
	{
		image_tmp_frame1 = (uint8_t*)malloc(pixel_size * 3);
	}
	if (image_tmp_frame2 == NULL)
	{
		image_tmp_frame2 = (uint8_t*)malloc(pixel_size * 3);
	}

	int timer = 0;
	while (is_streaming && frame_cnt<=stream_time*fps)
	{
		//printf("display thread %d\n",frame_cnt);
		sem_wait(&image_sem);
		display_one_frame(stream_frame_info);
		sem_post(&image_done_sem);
	}
	display_release();
	cv::destroyAllWindows();
	printf("display thread exit!!\n");
	return NULL;
}
