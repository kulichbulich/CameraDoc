#ifndef _CONFIG_H_
#define _CONFIG_H_


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "data.h"
#include "libiruvc.h"
#include "libirparse.h"
#include "libirprocess.h"
#include "spi.h"
#include "cmd.h"


void spi_and_sem_init();

int ir_camera_stream_on(StreamFrameInfo_t* stream_frame_info);

int ir_camera_stream_off();

//stream thread,get the raw frame, cut to temperature and image, and then send to other thread
void* stream_function(void* threadarg);


//user's call back function
void usr_test_func(void* frame, void* usr_param);


#endif
