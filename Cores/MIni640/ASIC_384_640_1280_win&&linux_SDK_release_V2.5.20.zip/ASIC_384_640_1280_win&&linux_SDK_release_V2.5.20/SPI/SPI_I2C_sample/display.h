#ifndef _DISPALAY_H_
#define _DISPALAY_H_

#include <stdint.h>

#include "libirparse.h"
#include "libirprocess.h"
#include "cmd.h"
#include <opencv2/imgproc.hpp>
#include <opencv2/highgui.hpp> 
#include <opencv2/highgui/highgui_c.h> 
//using namespace cv;

//initial the parameters for displaying
void display_init(void);

//release the parameters
void display_release(void);

//display one frame
void display_one_frame(StreamFrameInfo_t* stream_frame_info);

//display thread
void* display_function(void* threadarg);


#endif
