#include "camera.h"



#define BUFF_LEN 4096
#define DUMMY_LEN 512
int stream_time = 2000;  //unit:s
int fps=25;//if fps is 25
uint8_t is_streaming = 0;
int frame_cnt=0;

void spi_and_sem_init()
{
	int spiFd;
	spiFd = SPISetup(0,31200000);//31200000  spi clock frequency
    init_pthread_sem();
	if(spiFd==-1)
	{
		printf("init spi failed!\n");
	}
	init_pthread_sem();
}

int spi_frame_get(uint8_t* raw_frame, int frame_byte_size, int frame_type)
{
    uint8_t tx_Data[BUFF_LEN]={0};
	uint8_t rx_Data[BUFF_LEN]={0};
    uint16_t j=0;
    char new_frame_cmd = 0;
	char continue_cmd = 0x55;
    int i=0;
    if(frame_type==0)
    {
        new_frame_cmd = 0xAA;
        //printf("aa\n");
    }
    else if(frame_type==1)
    {
        new_frame_cmd = 0xCC;
        //printf("cc\n");
    }
    
    while(i<frame_byte_size)
    {
        if(i==0)
        {
            tx_Data[0] = new_frame_cmd;
            SPIDataRW(0, tx_Data, rx_Data, BUFF_LEN);
            memcpy(raw_frame + i, rx_Data + DUMMY_LEN, BUFF_LEN - DUMMY_LEN);//start from dummy and header
            i += BUFF_LEN - DUMMY_LEN;
            //for(j=480;j<484;j++)
                //printf("dummy_Data[%d]=%d\n",j,*(rx_Data+j));
        }
        else
        {
            tx_Data[0] = continue_cmd;
            SPIDataRW(0, tx_Data, rx_Data, BUFF_LEN);
            if(frame_byte_size-i>BUFF_LEN)
            {
				memcpy(raw_frame + i, rx_Data, BUFF_LEN);
			}
			else
			{
				memcpy(raw_frame + i, rx_Data, frame_byte_size-i);
			}
            i += BUFF_LEN;
        }
    }

    return 0;
}


//stream thread.this function can get the raw frame and cut it to image frame and temperature frame
//and send semaphore to image/temperature thread
void* stream_function(void* threadarg)
{
    
    StreamFrameInfo_t* stream_frame_info;
    stream_frame_info = (StreamFrameInfo_t*)threadarg;
    if (stream_frame_info == NULL)
    {
        return NULL;
    }
    int r = 0;
    int overtime_cnt = 0;
    int overtime_threshold = 3;
    
    while (is_streaming && (frame_cnt <= stream_time * fps))//display stream_time seconds
    {
		printf("");		//System call to enable phread_cancel
		if(stream_frame_info->frame_putput_format == IMAGE_AND_TEMP_MEANWHILE) 
		{
			sem_wait(&image_done_sem);
			sem_wait(&cmd_sem);
			r = spi_frame_get(stream_frame_info->image_frame, stream_frame_info->image_byte_size, 0);
			r += spi_frame_get(stream_frame_info->temp_frame, stream_frame_info->temp_byte_size, 1);
			sem_post(&image_sem);
			sem_post(&cmd_sem);
		}
		if(stream_frame_info->frame_putput_format == IMAGE_AND_TEMP_INTERLACE) 
		{
			if(frame_cnt%6!=0)
			{
				sem_wait(&image_done_sem);
				sem_wait(&cmd_sem);
				r = spi_frame_get(stream_frame_info->image_frame, stream_frame_info->image_byte_size, 0);
				sem_post(&image_sem);
				sem_post(&cmd_sem);
			}
			else
			{
				sem_wait(&cmd_sem);
				r = spi_frame_get(stream_frame_info->temp_frame, stream_frame_info->temp_byte_size, 1);
				sem_post(&cmd_sem);
			}
		}
		if(stream_frame_info->frame_putput_format == ONLY_IMAGE) 
		{
			sem_wait(&image_done_sem);
			sem_wait(&cmd_sem);
			r = spi_frame_get(stream_frame_info->image_frame, stream_frame_info->image_byte_size, 0);
			sem_post(&image_sem);
			sem_post(&cmd_sem);
		}
		if(stream_frame_info->frame_putput_format == ONLY_TEMP) 
		{
			if(frame_cnt==0)
			{
				basic_y16_preview(stream_frame_info->ircmd_handle,BASIC_Y16_MODE_TEMPERATURE);
				sleep(1);
			}
			sem_wait(&image_done_sem);
			sem_wait(&cmd_sem);
			r = spi_frame_get(stream_frame_info->image_frame, stream_frame_info->image_byte_size, 0);
			sem_post(&image_sem);
			sem_post(&cmd_sem);
			if(frame_cnt == stream_time * fps)
			{
                basic_y16_preview(stream_frame_info->ircmd_handle,BASIC_Y16_MODE_YUV);
				sleep(1);
			}
		}   
		if (r < 0)
		{
			overtime_cnt++;
		}
		else
		{
			overtime_cnt = 0;
		}
		if (r < 0 && overtime_cnt >= overtime_threshold)
		{				
			sem_post(&image_sem);
			sem_post(&cmd_sem);
        	basic_y16_preview(stream_frame_info->ircmd_handle,BASIC_Y16_MODE_YUV);
			printf("uvc_frame_get failed\n ");
			return NULL;
		}

		if (frame_cnt == stream_time * fps)
		{
			is_streaming = 0;
			sem_post(&image_sem);
			sem_post(&cmd_sem);
			break;
		}
     	frame_cnt++;
	}
    basic_y16_preview(stream_frame_info->ircmd_handle,BASIC_Y16_MODE_YUV);
    printf("stream thread exit!!\n");
    return NULL;
}


//user's call back function
void usr_test_func(void* frame, void* usr_param)
{
    printf("test_func:%d\n", ((unsigned short*)frame)[10]);
    printf("usr_param:%d\n", ((unsigned short*)usr_param));
    //write your own code here
}
